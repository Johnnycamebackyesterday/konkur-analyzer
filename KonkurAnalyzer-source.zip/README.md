# کارنامه‌ساز کنکور

یک برنامه native اندروید، کاملاً آفلاین، برای خواندن کلید پاسخ و پاسخ‌برگ آزمون‌های آزمایشی کنکور ایران و ساخت کارنامه.

## قابلیت‌های اصلی

- Kotlin + Jetpack Compose Material 3، RTL کامل و فونت bundled Vazirmatn
- minSdk 26، targetSdk 34، بدون مجوز اینترنت یا سرویس ابری
- ثبت آزمون با تاریخ شمسی، تعداد سؤال و بخش‌های اختیاری درس‌ها
- CameraX با راهنمای کادر، تشخیص لبه‌ها، deskew و ثبت خودکار پس از ثابت ماندن برگه
- OpenCV روی دستگاه: تشخیص چهارگوش برگه، تصحیح پرسپکتیو، حذف نور ناهمگون، تشخیص جدول و حباب‌ها
- خواندن رقم‌های فارسی با مدل MLP کوچک bundled، آموزش‌داده‌شده با داده synthetic چند فونت فارسی
- پشتیبانی از کلیدهای rows-of-pairs و column-based، حباب‌های خالی/چندعلامتی/گزینه ۱ تا ۴
- بازبینی کامل بعد از هر اسکن، ویرایش تک‌ضرب هر خانه و برجسته‌کردن confidence پایین
- محاسبه درصد نمره منفی کنکور: `(3 × صحیح − غلط) / (3 × کل) × 100`
- Room history، روند درصد آزمون‌ها، تفکیک درس‌ها، خروجی PDF فارسی RTL و Share
- تست‌های unit برای scoring، طبقه‌بندی حباب، layout parser، رقم فارسی و تاریخ شمسی
- سه تصویر synthetic در `app/src/main/assets/samples` و prototype قابل اجرای Python در `tools`

## ساخت

```bash
./gradlew assembleDebug
# یا خروجی release امضاشده با debug key:
./gradlew assembleRelease
```

برای build باید Android SDK Platform 34 و Gradle 8.7 در محیط توسعه موجود باشد. این محیط اجرایی فاقد Android SDK/Gradle distribution محلی بود، بنابراین APK از داخل این اجرا تولید نشد؛ سورس کامل، مدل، فونت، داده آزمایشی و تست‌ها در همین پروژه قرار دارند.

## ساختار

- `domain`: مدل، scoring خالص و use cases
- `data`: Room، mapper و repository
- `vision`: OpenCV، scannerها، classifier رقم و bubble logic
- `ui`: navigation، setup، camera, review, report, history
- `export`: PDF فارسی با Android text shaping
- `tools`: تولید داده، آموزش مدل digit و prototype pipeline
