import json, random, numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
random.seed(42); np.random.seed(42)
FONT = '/opt/sd-google-fonts/vazirmatn/Vazirmatn[wght].ttf'
FA = '۰۱۲۳۴۵۶۷۸۹'
def fa(n): return ''.join(FA[int(c)] for c in str(n))
def font(s): return ImageFont.truetype(FONT, s)
def photo(img, out, strength=1.0, bg=(120,110,95)):
    """Place page on a desk, apply perspective, uneven light, blur and noise."""
    a = np.array(img.convert('RGB'))[:, :, ::-1].copy()
    h, w = a.shape[:2]
    W, H = int(w*1.25), int(h*1.2)
    src = np.float32([[0,0],[w,0],[w,h],[0,h]])
    j = lambda: random.uniform(-0.04, 0.04)*w*strength
    ox, oy = (W-w)/2, (H-h)/2
    dst = np.float32([[ox+j(),oy+j()],[ox+w+j(),oy+j()],[ox+w+j(),oy+h+j()],[ox+j(),oy+h+j()]])
    M = cv2.getPerspectiveTransform(src, dst)
    canvas = np.full((H, W, 3), bg, np.uint8)
    warped = cv2.warpPerspective(a, M, (W, H), dst=canvas, borderMode=cv2.BORDER_TRANSPARENT)
    yy, xx = np.mgrid[0:H, 0:W]
    light = 0.65 + 0.35*(xx/W) * (0.8 + 0.2*np.sin(yy/H*3))
    warped = np.clip(warped*light[..., None], 0, 255)
    warped = cv2.GaussianBlur(warped, (0,0), 1.1)
    warped = np.clip(warped + np.random.normal(0, 6, warped.shape), 0, 255).astype(np.uint8)
    cv2.imwrite(out, warped, [cv2.IMWRITE_JPEG_QUALITY, 85])

def key_pairs(n=100, blocks=4, out='key_pairs.jpg'):
    ans = [random.randint(1,4) for _ in range(n)]
    rows = (n + blocks - 1)//blocks
    cw, rh, mx, top = 150, 52, 60, 200
    W = mx*2 + blocks*cw*2 + (blocks-1)*30; H = top + (rows+1)*rh + 80
    img = Image.new('L', (W, H), 255); d = ImageDraw.Draw(img)
    d.text((W//2-160, 60), 'کلید پاسخ آزمون آزمایشی', font=font(44), fill=0)
    for b in range(blocks):
        x1 = W - mx - b*(2*cw+30)          # right edge of this block (RTL)
        x0 = x1 - 2*cw
        y0 = top; y1 = top + (rows+1)*rh
        for r in range(rows+2): d.line([(x0, y0+r*rh), (x1, y0+r*rh)], fill=0, width=2) if r <= rows+1 and y0+r*rh <= y1 else None
        for c in range(3): d.line([(x0+c*cw, y0), (x0+c*cw, y1)], fill=0, width=2)
        d.text((x1-cw+30, y0+8), 'سوال', font=font(28), fill=0)
        d.text((x0+30, y0+8), 'گزینه', font=font(28), fill=0)
        for r in range(rows):
            q = b*rows + r + 1
            if q > n: break
            y = y0 + (r+1)*rh + 6
            d.text((x1-cw+50, y), fa(q), font=font(32), fill=0)
            d.text((x0+cw//2-8, y), fa(ans[q-1]), font=font(32), fill=0)
    photo(img, out)
    return ans

def key_columns(n=60, per=20, out='key_columns.jpg'):
    ans = [random.randint(1,4) for _ in range(n)]
    bands = (n+per-1)//per
    cw, rh, mx, top = 64, 56, 50, 180
    W = mx*2 + per*cw; H = top + bands*(2*rh+40) + 60
    img = Image.new('L', (W, H), 255); d = ImageDraw.Draw(img)
    d.text((W//2-150, 50), 'پاسخنامه کلیدی', font=font(44), fill=0)
    for b in range(bands):
        y0 = top + b*(2*rh+40)
        for r in range(3): d.line([(mx, y0+r*rh), (W-mx, y0+r*rh)], fill=0, width=2)
        for c in range(per+1): d.line([(mx+c*cw, y0), (mx+c*cw, y0+2*rh)], fill=0, width=2)
        for c in range(per):
            q = b*per + c + 1
            if q > n: break
            x = W - mx - (c+1)*cw  # RTL columns
            t = fa(q); tw = d.textlength(t, font=font(28))
            d.text((x+(cw-tw)/2, y0+10), t, font=font(28), fill=0)
            t = fa(ans[q-1]); tw = d.textlength(t, font=font(30))
            d.text((x+(cw-tw)/2, y0+rh+8), t, font=font(30), fill=0)
    photo(img, out)
    return ans

def sheet(n=100, blocks=4, key=None, out='sheet.jpg'):
    rows = (n+blocks-1)//blocks
    bw, bh, gap, qw, rh, mx, top = 46, 28, 14, 70, 50, 70, 230
    blockW = qw + 4*bw + 3*gap
    W = mx*2 + blocks*blockW + (blocks-1)*60; H = top + rows*rh + 100
    img = Image.new('L', (W, H), 255); d = ImageDraw.Draw(img)
    d.text((W//2-140, 60), 'پاسخبرگ داوطلب', font=font(46), fill=0)
    d.rectangle([20, 20, W-20, H-20], outline=0, width=3)
    marks = []
    for q in range(1, n+1):
        b, r = (q-1)//rows, (q-1) % rows
        x1 = W - mx - b*(blockW+60)
        y = top + r*rh
        d.text((x1-qw+10, y-4), fa(q), font=font(26), fill=0)
        k = key[q-1] if key else random.randint(1,4)
        p = random.random()
        if p < 0.08: m = []
        elif p < 0.12: m = random.sample([1,2,3,4], 2)
        elif p < 0.70: m = [k]
        else: m = [random.choice([o for o in (1,2,3,4) if o != k])]
        marks.append(m)
        for o in range(4):
            bx = x1 - qw - (4-o)*bw - (3-o)*gap   # option 1 leftmost
            box = [bx, y, bx+bw, y+bh]
            d.ellipse(box, outline=0, width=2)
            t = fa(o+1); d.text((bx+bw/2-6, y-3), t, font=font(18), fill=90)
            if (o+1) in m:
                sh = random.randint(-3, 3)
                d.ellipse([bx+3+sh, y+3, bx+bw-3+sh, y+bh-3], fill=random.randint(15, 60))
    photo(img, out, strength=0.8)
    res = [ (m[0] if len(m) == 1 else (0 if not m else -1)) for m in marks]
    return res

k1 = key_pairs(); k2 = key_columns(); s = sheet(key=k1)
json.dump({'key_pairs': k1, 'key_columns': k2, 'sheet': s, 'sheet_options_order': 'ltr', 'sheet_blocks_order': 'rtl'}, open('expected.json', 'w'))
print('ok')
