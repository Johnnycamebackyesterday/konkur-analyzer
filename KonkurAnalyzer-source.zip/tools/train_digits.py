"""Generates a synthetic Persian-digit dataset from bundled-style fonts and trains a small MLP.
Output: digit_mlp.bin (little-endian): int32 magic 0x4B4F4E4B, int32 in, int32 hidden, int32 out,
then W1[in*hidden] (row-major in x hidden), b1[hidden], W2[hidden*out], b2[out] as float32."""
import glob, random, struct, sys
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
from sklearn.neural_network import MLPClassifier
random.seed(7); np.random.seed(7)
FONTS = sys.argv[1:] 
def normalize(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) == 0: return None
    crop = mask[ys.min():ys.max()+1, xs.min():xs.max()+1].astype(np.float32)
    h, w = crop.shape; s = 20.0 / max(h, w)
    nw, nh = max(1, int(round(w*s))), max(1, int(round(h*s)))
    r = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA)
    out = np.zeros((28, 28), np.float32)
    x0, y0 = (28-nw)//2, (28-nh)//2
    out[y0:y0+nh, x0:x0+nw] = r
    return out.reshape(-1)
def render(font_path, d, size):
    f = ImageFont.truetype(font_path, size)
    img = Image.new('L', (size*3, size*3), 255)
    ImageDraw.Draw(img).text((size, size//2), chr(0x6F0+d), font=f, fill=0)
    a = np.array(img)
    # augment
    ang = random.uniform(-9, 9); sc = random.uniform(0.9, 1.1)
    M = cv2.getRotationMatrix2D((a.shape[1]/2, a.shape[0]/2), ang, sc)
    M[0,1] += random.uniform(-0.15, 0.15)
    a = cv2.warpAffine(a, M, (a.shape[1], a.shape[0]), borderValue=255)
    if random.random() < 0.6: a = cv2.GaussianBlur(a, (0,0), random.uniform(0.3, 1.6))
    a = np.clip(a.astype(np.float32) + np.random.normal(0, random.uniform(0, 25), a.shape), 0, 255).astype(np.uint8)
    _, b = cv2.threshold(a, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    k = random.choice([0, 0, 1, 2])
    if k == 1: b = cv2.erode(b, np.ones((2,2), np.uint8))
    if k == 2: b = cv2.dilate(b, np.ones((2,2), np.uint8))
    # keep the largest connected component (inference works per-component)
    n, lab, st, _ = cv2.connectedComponentsWithStats(b, 8)
    if n < 2: return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    return normalize((lab == i).astype(np.uint8))
X, Y = [], []
for fp in FONTS:
    for d in range(10):
        for _ in range(140):
            v = render(fp, d, random.randint(28, 72))
            if v is not None: X.append(v); Y.append(d)
X = np.array(X); Y = np.array(Y)
idx = np.random.permutation(len(X)); X, Y = X[idx], Y[idx]
n = int(len(X)*0.85)
clf = MLPClassifier(hidden_layer_sizes=(96,), max_iter=60, alpha=1e-4, random_state=1)
clf.fit(X[:n], Y[:n])
print('train', clf.score(X[:n], Y[:n]), 'val', clf.score(X[n:], Y[n:]), 'N', len(X))
from sklearn.metrics import confusion_matrix
print(confusion_matrix(Y[n:], clf.predict(X[n:])))
W1, W2 = clf.coefs_; b1, b2 = clf.intercepts_
with open('digit_mlp.bin', 'wb') as fo:
    fo.write(struct.pack('<4i', 0x4B4F4E4B, W1.shape[0], W1.shape[1], W2.shape[1]))
    for arr in (W1, b1, W2, b2): fo.write(arr.astype('<f4').tobytes())
np.save('val_X.npy', X[n:n+50]); np.save('val_Y.npy', Y[n:n+50])
