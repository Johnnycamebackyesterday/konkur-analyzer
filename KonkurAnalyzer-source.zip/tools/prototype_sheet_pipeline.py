from prototype_key_pipeline import *
def classify(f, thr):
    mn = min(f); marked = [i for i,v in enumerate(f) if v >= thr and v - mn >= 0.2]
    s = sorted(f, reverse=True)
    if not marked: return 0, float(np.clip((thr - s[0])/(thr*0.5), 0, 1))
    if len(marked) == 1: return marked[0]+1, float(np.clip((s[0]-s[1])/0.35, 0, 1))
    top = sorted(marked, key=lambda i: -f[i])
    if f[top[1]] >= 0.75*f[top[0]]: return -1, float(np.clip((f[top[1]]-thr)/0.3, 0, 1))
    return top[0]+1, 0.4
def global_thr(fills):
    v = np.sort(np.array(fills)); best=(None, -1)
    for t in np.linspace(0.2, 0.7, 51):
        lo, hi = v[v<t], v[v>=t]
        if len(lo)==0 or len(hi)==0: continue
        score = len(lo)*len(hi)*(hi.mean()-lo.mean())**2
        if score > best[1]: best=(t, score)
    t = best[0] if best[0] is not None else 0.45
    return float(np.clip(t, 0.3, 0.6))
def scan_sheet(path, N, opt_ltr=True, blocks_rtl=True):
    g = prep(path); H, W = g.shape
    b = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 41, 12)
    cs,_ = cv2.findContours(b, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cand=[]
    for c in cs:
        x,y,w,h = cv2.boundingRect(c)
        if w < 0.006*W or h < 0.006*W or w > 0.08*W or h > 0.08*W: continue
        ar = w/h
        if not 0.7 <= ar <= 2.6: continue
        a = cv2.contourArea(c); per = cv2.arcLength(c, True)
        circ = 4*np.pi*a/(per*per+1e-6)
        if circ < 0.6: continue
        cand.append((x,y,w,h))
    if not cand: return None
    mw = np.median([c[2] for c in cand]); mh = np.median([c[3] for c in cand])
    cand = [c for c in cand if 0.7*mw <= c[2] <= 1.3*mw and 0.7*mh <= c[3] <= 1.3*mh]
    # dedupe nested (outer/inner ring contours)
    cand.sort(key=lambda c: -c[2]*c[3]); keep=[]
    for c in cand:
        cx, cy = c[0]+c[2]/2, c[1]+c[3]/2
        if all(abs(cx-(k[0]+k[2]/2)) > 0.5*mw or abs(cy-(k[1]+k[3]/2)) > 0.5*mh for k in keep): keep.append(c)
    print('bubbles', len(keep), mw, mh)
    rows = [[keep[i] for i in gg] for gg in cluster([c[1]+c[3]/2 for c in keep], 0.5*mh)]
    groups=[]
    for r in rows:
        r.sort(key=lambda c: c[0])
        if len(r) < 4: continue
        gaps = [r[i+1][0]-(r[i][0]+r[i][2]) for i in range(len(r)-1)]
        ig = np.median(sorted(gaps)[:max(1,len(gaps)*3//4)])
        cur=[r[0]]
        for i in range(1,len(r)):
            if gaps[i-1] > max(1.8*ig, ig + 0.6*mw): groups.append(cur); cur=[]
            cur.append(r[i])
        groups.append(cur)
    qs=[]
    for gq in groups:
        if len(gq) % 4: continue
        for k in range(0, len(gq), 4): qs.append(gq[k:k+4])
    print('questions found', len(qs))
    # fills
    _, ob = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    def fill(c):
        x,y,w,h = c; mask = np.zeros((h,w), np.uint8)
        cv2.ellipse(mask, (w//2,h//2), (max(1,int(w*0.34)), max(1,int(h*0.32))), 0, 0, 360, 255, -1)
        roi = ob[y:y+h, x:x+w]; return float((roi[mask>0]>0).mean())
    F = [[fill(c) for c in q] for q in qs]
    thr = global_thr([v for f in F for v in f]); print('thr', thr)
    # block columns
    bc = cluster([np.mean([c[0] for c in q]) for q in qs], 2*mw)
    bc.sort(key=lambda gg: -np.mean([qs[i][0][0] for i in gg]) if blocks_rtl else np.mean([qs[i][0][0] for i in gg]))
    order=[]
    for gg in bc: order += sorted(gg, key=lambda i: qs[i][0][1])
    res=[]
    for i in order[:N]:
        f = F[i] if opt_ltr else F[i][::-1]
        res.append(classify(f, thr))
    return res
if __name__ == '__main__':
    r = scan_sheet(os.path.join(ASSET, 'sheet.jpg'), 100); exp = E['sheet']
    bad = [(q+1, exp[q], r[q]) for q in range(len(exp)) if q >= len(r) or r[q][0] != exp[q]]
    print('correct', len(exp)-len(bad), bad[:10], 'lowconf', sum(1 for x in r if x[1] < 0.6))
