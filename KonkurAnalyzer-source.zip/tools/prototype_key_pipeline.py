import json, struct, numpy as np, cv2, sys
def load_mlp(p=None):
    import os
    p = p or os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'models', 'digit_mlp.bin')
    b = open(p,'rb').read(); m, i, h, o = struct.unpack('<4i', b[:16]); a = np.frombuffer(b[16:], '<f4'); k=0
    W1 = a[k:k+i*h].reshape(i,h); k+=i*h; b1=a[k:k+h]; k+=h; W2=a[k:k+h*o].reshape(h,o); k+=h*o; b2=a[k:k+o]
    def f(x):
        z = np.maximum(x@W1+b1, 0)@W2+b2; e=np.exp(z-z.max()); return e/e.sum()
    return f
MLP = load_mlp()
def order_pts(p):
    s = p.sum(1); d = p[:,1]-p[:,0]
    return np.float32([p[np.argmin(s)], p[np.argmin(d)], p[np.argmax(s)], p[np.argmax(d)]])
def find_doc(gray):
    sc = 600/max(gray.shape); sm = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    sm = cv2.GaussianBlur(sm, (5,5), 0)
    e = cv2.Canny(sm, 40, 120); e = cv2.dilate(e, np.ones((3,3),np.uint8))
    cs,_ = cv2.findContours(e, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best=None; ba=0
    for c in cs:
        a = cv2.contourArea(c)
        if a < 0.2*sm.shape[0]*sm.shape[1]: continue
        ap = cv2.approxPolyDP(c, 0.02*cv2.arcLength(c,True), True)
        if len(ap)==4 and cv2.isContourConvex(ap) and a>ba: best, ba = ap.reshape(4,2)/sc, a
    return None if best is None else order_pts(best.astype(np.float32))
def warp(gray, q):
    tl,tr,br,bl = q
    w = int(max(np.linalg.norm(tr-tl), np.linalg.norm(br-bl))); h = int(max(np.linalg.norm(bl-tl), np.linalg.norm(br-tr)))
    M = cv2.getPerspectiveTransform(q, np.float32([[0,0],[w,0],[w,h],[0,h]]))
    return cv2.warpPerspective(gray, M, (w,h))
def flatten(gray):
    k = max(15, (min(gray.shape)//20)|1)
    bg = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(k,k)))
    return cv2.divide(gray, bg, scale=255)
def prep(path):
    g = cv2.imread(path, 0); s = min(1.0, 2000/max(g.shape))
    g = cv2.resize(g, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    q = find_doc(g); print('doc', q is not None)
    if q is not None: g = warp(g, q)
    return flatten(g)
def normalize(mask):
    ys, xs = np.nonzero(mask); crop = mask[ys.min():ys.max()+1, xs.min():xs.max()+1].astype(np.float32)
    h, w = crop.shape; s = 20.0/max(h,w); nw, nh = max(1,int(round(w*s))), max(1,int(round(h*s)))
    r = cv2.resize(crop,(nw,nh),interpolation=cv2.INTER_AREA); out=np.zeros((28,28),np.float32)
    x0,y0=(28-nw)//2,(28-nh)//2; out[y0:y0+nh,x0:x0+nw]=r; return out.reshape(-1)
def key_tokens(g):
    H, W = g.shape
    b = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 31, 15)
    hl = cv2.morphologyEx(b, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT,(max(10,W//25),1)))
    vl = cv2.morphologyEx(b, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT,(1,max(10,H//25))))
    lines = cv2.dilate(hl|vl, np.ones((3,3),np.uint8))
    t = cv2.bitwise_and(b, cv2.bitwise_not(lines))
    n, lab, st, cen = cv2.connectedComponentsWithStats(t, 8)
    hs = [st[i,3] for i in range(1,n) if 0.008*H <= st[i,3] <= 0.08*H and st[i,4] >= 12 and 0.3 <= st[i,3]/max(1,st[i,2]) <= 8]
    if not hs: return [], 0
    m = float(np.median(hs)); comps=[]
    for i in range(1,n):
        x,y,w,h,a = st[i]
        if h > 1.7*m or w > 1.5*m or a < 0.02*m*m: continue
        zlike = 0.12*m <= h < 0.62*m and 0.5 <= w/max(1,h) <= 2.2 and a >= 0.35*w*h
        if h >= 0.45*m:
            p = MLP(normalize((lab[y:y+h,x:x+w]==i).astype(np.uint8))); d=int(np.argmax(p))
            if h >= 0.62*m or (d == 5 and p[d] > 0.9):
                if d != 0: comps.append(dict(d=d, c=float(p[d]), x=x,y=y,w=w,h=h,cx=x+w/2,cy=y+h/2))
                continue
        if zlike: comps.append(dict(d=0, c=0.8, x=x,y=y,w=w,h=h,cx=x+w/2,cy=y+h/2, z=True))
    # line clustering
    comps.sort(key=lambda c: c['cy']); lines=[]
    for c in comps:
        if lines and abs(lines[-1][-1]['cy'] - c['cy']) < 0.6*m and not c.get('z') : lines[-1].append(c)
        elif lines and c.get('z') and abs(np.mean([k['cy'] for k in lines[-1]]) - c['cy']) < 0.7*m: lines[-1].append(c)
        else: lines.append([c])
    toks=[]
    for L in lines:
        L.sort(key=lambda c: c['x']); cur=[]
        for c in L:
            if cur and c['x'] - (cur[-1]['x']+cur[-1]['w']) > 0.55*m: toks.append(cur); cur=[]
            cur.append(c)
        if cur: toks.append(cur)
    out=[]
    for T in toks:
        if all(c.get('z') for c in T): continue
        while T and T[0].get('z'): T=T[1:]   # leading zeros impossible
        if not T: continue
        v = int(''.join(str(c['d']) for c in T))
        x0=min(c['x'] for c in T); x1=max(c['x']+c['w'] for c in T); y0=min(c['y'] for c in T); y1=max(c['y']+c['h'] for c in T)
        out.append(dict(v=v, n=len(T), c=min(c['c'] for c in T), cx=(x0+x1)/2, cy=(y0+y1)/2, w=x1-x0, h=y1-y0))
    return out, m
def cluster(vals, tol):
    idx = sorted(range(len(vals)), key=lambda i: vals[i]); gs=[]
    for i in idx:
        if gs and vals[i]-np.mean([vals[j] for j in gs[-1]]) <= tol: gs[-1].append(i)
        else: gs.append([i])
    return gs
def seq_score(vals):
    if len(vals)<3: return 0
    return sum(1 for a,b in zip(vals,vals[1:]) if b==a+1)/(len(vals)-1)
def repair(ts, N):
    """ts sorted in reading order; returns list of (token, number, conf) after sequence repair."""
    if len(ts) < 3: return [(t, t['v'], t['c']) for t in ts]
    offs = {}
    for i,t in enumerate(ts): offs[t['v']-i] = offs.get(t['v']-i, 0) + 1
    o, cnt = max(offs.items(), key=lambda kv: kv[1])
    if cnt < 2: return [(t, t['v'], t['c']) for t in ts]
    good = [i for i,t in enumerate(ts) if t['v']-i == o]
    out=[]
    for i,t in enumerate(ts):
        q = i + o
        if t['v'] == q: out.append((t, q, t['c']))
        elif good[0] <= i <= good[-1] or (1 <= q <= N and abs(i-good[0]) <= 2) : 
            if 1 <= q <= N: out.append((t, q, min(t['c'], 0.55)))
    return out
def fit_line(ts, key, N):
    """RANSAC fit number = a + b*pos over tokens; returns (a,b,inliers) or None."""
    c = [t for t in ts if 1 <= t['v'] <= N]
    best=None
    for i in range(len(c)):
        for j in range(i+1, len(c)):
            dp = c[j][key]-c[i][key]
            if abs(dp) < 1e-3 or c[j]['v'] == c[i]['v']: continue
            b = (c[j]['v']-c[i]['v'])/dp; a = c[i]['v'] - b*c[i][key]
            inl = [t for t in c if abs(a+b*t[key]-t['v']) < 0.35]
            if best is None or len(inl) > len(best[2]): best = (a,b,inl)
    if best is None or len(best[2]) < 3: return None
    # least squares refine on inliers
    P = np.array([t[key] for t in best[2]]); V = np.array([t['v'] for t in best[2]])
    b, a = np.polyfit(P, V, 1)
    return a, b, best[2]
def assign(ans_ts, num_ts, key, N, m, res):
    f = fit_line(num_ts, key, N)
    if f is None: return
    a, b, inl = f
    for t in ans_ts:
        if not (t['n']==1 and 1<=t['v']<=4): continue
        q = int(round(a + b*t[key]))
        if not (1 <= q <= N): continue
        near = [u for u in inl if u['v']==q and abs(u[key]-t[key]) < 0.8*m]
        conf = min(t['c'], near[0]['c']) if near else min(t['c'], 0.55)
        if q not in res or res[q][1] < conf: res[q] = (t['v'], conf)
def is_answer(ts): return len(ts)>=2 and sum(1 for t in ts if t['n']==1 and 1<=t['v']<=4)/len(ts) >= 0.8 and seq_score([t['v'] for t in ts]) < 0.5
def parse(toks, m, N):
    best={}
    # A: columns
    cols = [[toks[i] for i in g] for g in cluster([t['cx'] for t in toks], 0.9*m)]
    for c in cols: c.sort(key=lambda t: t['cy'])
    numc = [c for c in cols if seq_score([t['v'] for t in c]) >= 0.5]
    ansc = [c for c in cols if is_answer(c)]
    resA={}
    for a in ansc:
        ax = np.mean([t['cx'] for t in a])
        right = [c for c in numc if np.mean([t['cx'] for t in c]) > ax]
        cand = right or numc
        if not cand: continue
        nc = min(cand, key=lambda c: abs(np.mean([t['cx'] for t in c]) - ax))
        assign(a, nc, 'cy', N, m, resA)
    # B: rows
    rows = [[toks[i] for i in g] for g in cluster([t['cy'] for t in toks], 0.6*m)]
    for r in rows: r.sort(key=lambda t: -t['cx'])
    rows.sort(key=lambda r: np.mean([t['cy'] for t in r]))
    resB={}
    for i, r in enumerate(rows):
        if not is_answer(r) or i == 0: continue
        prev = [p for p in rows[:i] if max(seq_score([t['v'] for t in p]), seq_score([t['v'] for t in p][::-1])) >= 0.5]
        if not prev: continue
        nr = prev[-1]
        assign(r, nr, 'cx', N, m, resB)
    print('A', len(resA), 'B', len(resB))
    return resA if len(resA) >= len(resB) else resB
def eval_key(path, exp):
    g = prep(path); toks, m = key_tokens(g); print('tokens', len(toks), 'm', m)
    r = parse(toks, m, len(exp))
    ok = sum(1 for q,a in enumerate(exp,1) if q in r and r[q][0]==a)
    print(path, 'found', len(r), 'correct', ok, '/', len(exp))
import os
ASSET = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'samples')
E = json.load(open(os.path.join(ASSET, 'expected.json')))
if __name__ == '__main__':
    eval_key(os.path.join(ASSET, 'key_pairs.jpg'), E['key_pairs']); eval_key(os.path.join(ASSET, 'key_columns.jpg'), E['key_columns'])
