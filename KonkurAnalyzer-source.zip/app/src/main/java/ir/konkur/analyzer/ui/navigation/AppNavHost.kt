package ir.konkur.analyzer.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import ir.konkur.analyzer.di.AppContainer
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel
import ir.konkur.analyzer.ui.screens.history.HistoryScreen
import ir.konkur.analyzer.ui.screens.home.HomeScreen
import ir.konkur.analyzer.ui.screens.report.ReportScreen
import ir.konkur.analyzer.ui.screens.review.ReviewScreen
import ir.konkur.analyzer.ui.screens.scan.ScanScreen
import ir.konkur.analyzer.ui.screens.setup.SetupScreen

object Routes {
    const val HOME = "home"
    const val SETUP = "setup"
    const val SCAN_KEY = "scan_key"
    const val SCAN_SHEET = "scan_sheet"
    const val REVIEW_KEY = "review_key"
    const val REVIEW_SHEET = "review_sheet"
    const val REPORT = "report"
    const val HISTORY = "history"
}

@Composable
fun AppNavHost(container: AppContainer, nav: NavHostController = rememberNavController()) {
    val flow = ExamFlowViewModel.remember(container)
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(flow, onNew = { flow.reset(); nav.navigate(Routes.SETUP) }, onHistory = { nav.navigate(Routes.HISTORY) }) }
        composable(Routes.SETUP) { SetupScreen(flow, onBack = { nav.popBackStack() }, onNext = { nav.navigate(Routes.SCAN_KEY) }) }
        composable(Routes.SCAN_KEY) { ScanScreen(flow, kind = ir.konkur.analyzer.ui.screens.scan.ScanKind.KEY, onBack = { nav.popBackStack() }, onReview = { nav.navigate(Routes.REVIEW_KEY) }) }
        composable(Routes.REVIEW_KEY) { ReviewScreen(flow, kind = ir.konkur.analyzer.ui.screens.review.ReviewKind.KEY, onBack = { nav.popBackStack() }, onNext = { nav.navigate(Routes.SCAN_SHEET) }) }
        composable(Routes.SCAN_SHEET) { ScanScreen(flow, kind = ir.konkur.analyzer.ui.screens.scan.ScanKind.SHEET, onBack = { nav.popBackStack() }, onReview = { nav.navigate(Routes.REVIEW_SHEET) }) }
        composable(Routes.REVIEW_SHEET) { ReviewScreen(flow, kind = ir.konkur.analyzer.ui.screens.review.ReviewKind.SHEET, onBack = { nav.popBackStack() }, onNext = { nav.navigate(Routes.REPORT) }) }
        composable(Routes.REPORT) { ReportScreen(flow, container, onHome = { nav.popBackStack(Routes.HOME, false) }, onHistory = { nav.navigate(Routes.HISTORY) }) }
        composable(Routes.HISTORY) { HistoryScreen(container, onBack = { nav.popBackStack() }, onOpen = { id -> flow.load(id) { nav.navigate(Routes.REPORT) } }) }
    }
}
