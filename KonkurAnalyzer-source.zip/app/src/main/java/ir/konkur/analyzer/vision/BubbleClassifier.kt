package ir.konkur.analyzer.vision

import ir.konkur.analyzer.domain.model.Answer
import kotlin.math.max

data class BubbleDecision(val value: Int, val confidence: Float)

/**
 * Pure (OpenCV-free) decision logic for one question row of 4 bubbles.
 * Input values are fill ratios in 0..1 (fraction of dark pixels inside the inner ellipse).
 */
object BubbleClassifier {
    const val DEFAULT_THRESHOLD = 0.45f
    private const val MIN_CONTRAST = 0.2f
    private const val MULTI_RATIO = 0.75f

    fun classify(fills: FloatArray, threshold: Float = DEFAULT_THRESHOLD): BubbleDecision {
        require(fills.size == 4) { "exactly 4 options expected" }
        val min = fills.min()
        val marked = fills.indices.filter { fills[it] >= threshold && fills[it] - min >= MIN_CONTRAST }
        val sorted = fills.sortedDescending()
        return when (marked.size) {
            0 -> BubbleDecision(Answer.BLANK, clamp((threshold - sorted[0]) / (threshold * 0.5f)))
            1 -> BubbleDecision(marked[0] + 1, clamp((sorted[0] - sorted[1]) / 0.35f))
            else -> {
                val top = marked.sortedByDescending { fills[it] }
                val first = fills[top[0]]
                val second = fills[top[1]]
                if (second >= MULTI_RATIO * first) {
                    BubbleDecision(Answer.MULTI, clamp((second - threshold) / 0.3f))
                } else {
                    // One strong mark plus a weaker one (typically an erasure): keep the strong one, flag it.
                    BubbleDecision(top[0] + 1, 0.4f)
                }
            }
        }
    }

    /**
     * Picks a global fill threshold for the whole sheet by maximising between-class variance
     * (Otsu on the 1-D distribution of fill ratios). Clamped to a sane range so that a sheet with
     * all-blank or all-filled answers still behaves.
     */
    fun globalThreshold(allFills: FloatArray): Float {
        if (allFills.size < 8) return DEFAULT_THRESHOLD
        val v = allFills.sorted()
        var bestT = DEFAULT_THRESHOLD
        var bestScore = -1.0
        var t = 0.2f
        while (t <= 0.7001f) {
            var nLo = 0; var sLo = 0.0; var nHi = 0; var sHi = 0.0
            for (x in v) if (x < t) { nLo++; sLo += x } else { nHi++; sHi += x }
            if (nLo > 0 && nHi > 0) {
                val d = sHi / nHi - sLo / nLo
                val score = nLo.toDouble() * nHi * d * d
                if (score > bestScore) { bestScore = score; bestT = t }
            }
            t += 0.01f
        }
        // If the distribution is not bimodal (no real marks) fall back to the default.
        val hiMean = v.filter { it >= bestT }.average()
        if (hiMean < 0.35) return max(DEFAULT_THRESHOLD, bestT)
        return bestT.coerceIn(0.3f, 0.6f)
    }

    private fun clamp(x: Float) = x.coerceIn(0f, 1f)
}
