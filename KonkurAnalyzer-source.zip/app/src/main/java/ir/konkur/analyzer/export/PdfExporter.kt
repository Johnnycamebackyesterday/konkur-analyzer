package ir.konkur.analyzer.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import ir.konkur.analyzer.core.JalaliCalendar
import ir.konkur.analyzer.core.PersianDigits
import ir.konkur.analyzer.core.fa
import ir.konkur.analyzer.core.faPercent
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.model.QuestionOutcome
import java.io.File
import java.io.FileOutputStream

/**
 * Renders the report card to an A4 PDF using Android's text engine (proper Persian shaping and
 * bidi) with the bundled Vazirmatn font, then shares it through a FileProvider.
 */
class PdfExporter(private val context: Context) {
    private val regular: Typeface by lazy {
        runCatching { Typeface.createFromAsset(context.assets, "fonts/Vazirmatn-Regular.ttf") }.getOrDefault(Typeface.DEFAULT)
    }
    private val bold: Typeface by lazy {
        runCatching { Typeface.createFromAsset(context.assets, "fonts/Vazirmatn-Bold.ttf") }.getOrDefault(Typeface.DEFAULT_BOLD)
    }

    private companion object {
        const val PAGE_W = 595
        const val PAGE_H = 842
        const val MARGIN = 36f
        val PRIMARY = Color.rgb(46, 58, 140)
        val GREEN = Color.rgb(46, 125, 50)
        val RED = Color.rgb(198, 40, 40)
        val GRAY = Color.rgb(117, 117, 117)
        val LIGHT = Color.rgb(236, 239, 250)
    }

    private inner class Writer(private val doc: PdfDocument) {
        var page: PdfDocument.Page? = null
        lateinit var canvas: Canvas
        var y = MARGIN
        var pageNo = 0
        val contentW get() = PAGE_W - 2 * MARGIN

        fun newPage() {
            page?.let { finishPage(it) }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            page = p; canvas = p.canvas; y = MARGIN
        }

        private fun finishPage(p: PdfDocument.Page) {
            text("صفحه ${pageNo.fa()} • تولیدشده به‌صورت آفلاین با کارنامه‌ساز کنکور", MARGIN, PAGE_H - 26f, contentW, 8f, false, GRAY, Layout.Alignment.ALIGN_CENTER)
            doc.finishPage(p)
        }

        fun finish() { page?.let { finishPage(it) }; page = null }

        fun ensure(h: Float) { if (y + h > PAGE_H - 44f) newPage() }

        fun layout(s: String, width: Float, size: Float, isBold: Boolean, color: Int, align: Layout.Alignment): StaticLayout {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = if (isBold) bold else regular
                textSize = size
                this.color = color
            }
            return StaticLayout.Builder.obtain(s, 0, s.length, paint, width.toInt().coerceAtLeast(10))
                .setAlignment(align)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.15f)
                .setIncludePad(false)
                .build()
        }

        /** Draws [s] in the box starting at [left]; returns its height. ALIGN_NORMAL = right-aligned in RTL. */
        fun text(
            s: String, left: Float, top: Float, width: Float, size: Float, isBold: Boolean = false,
            color: Int = Color.BLACK, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
        ): Float {
            val l = layout(s, width, size, isBold, color, align)
            canvas.save(); canvas.translate(left, top); l.draw(canvas); canvas.restore()
            return l.height.toFloat()
        }

        fun paragraph(s: String, size: Float, color: Int = Color.BLACK) {
            val l = layout(s, contentW, size, false, color, Layout.Alignment.ALIGN_NORMAL)
            // Split long paragraphs across pages line by line.
            var line = 0
            while (line < l.lineCount) {
                ensure(l.getLineBottom(line).toFloat() - l.getLineTop(line))
                val available = PAGE_H - 44f - y
                var last = line
                while (last + 1 < l.lineCount && l.getLineBottom(last + 1) - l.getLineTop(line) <= available) last++
                val top = l.getLineTop(line).toFloat(); val bottom = l.getLineBottom(last).toFloat()
                canvas.save()
                canvas.translate(MARGIN, y - top)
                canvas.clipRect(0f, top, contentW, bottom)
                l.draw(canvas)
                canvas.restore()
                y += bottom - top
                line = last + 1
                if (line < l.lineCount) newPage()
            }
        }
    }

    fun export(exam: Exam): File {
        val doc = PdfDocument()
        try {
            val w = Writer(doc)
            w.newPage()
            val r = exam.report
            val fill = Paint(Paint.ANTI_ALIAS_FLAG)

            // Header band
            fill.color = PRIMARY
            w.canvas.drawRoundRect(RectF(MARGIN, w.y, PAGE_W - MARGIN, w.y + 74f), 12f, 12f, fill)
            w.text("کارنامه آزمون", MARGIN + 16, w.y + 10, w.contentW - 32, 11f, false, Color.argb(220, 255, 255, 255))
            w.text(exam.config.name, MARGIN + 16, w.y + 26, w.contentW - 32, 18f, true, Color.WHITE)
            w.text(JalaliCalendar.fromMillis(exam.config.dateMillis).formatLong(), MARGIN + 16, w.y + 30, w.contentW - 32, 10f,
                false, Color.WHITE, Layout.Alignment.ALIGN_OPPOSITE)
            w.y += 90f

            // Summary boxes (right to left)
            val boxes = listOf(
                Triple("درصد (با نمره منفی)", r.percent.faPercent(), PRIMARY),
                Triple("درصد خام", r.rawPercent.faPercent(), PRIMARY),
                Triple("صحیح", r.correct.fa(), GREEN),
                Triple("غلط", r.wrong.fa(), RED),
                Triple("نزده", r.blank.fa(), GRAY),
            )
            val gap = 8f
            val bw = (w.contentW - gap * (boxes.size - 1)) / boxes.size
            boxes.forEachIndexed { i, (label, value, color) ->
                val right = PAGE_W - MARGIN - i * (bw + gap)
                val rect = RectF(right - bw, w.y, right, w.y + 64f)
                fill.color = LIGHT
                w.canvas.drawRoundRect(rect, 10f, 10f, fill)
                w.text(value, rect.left, rect.top + 10, bw, 17f, true, color, Layout.Alignment.ALIGN_CENTER)
                w.text(label, rect.left, rect.top + 40, bw, 8.5f, false, GRAY, Layout.Alignment.ALIGN_CENTER)
            }
            w.y += 76f
            val cancelled = if (r.cancelled > 0) " • سؤالات حذف‌شده: ${r.cancelled.fa()}" else ""
            w.y += w.text("تعداد کل سؤالات: ${r.total.fa()}$cancelled • فرمول: (۳ × صحیح − غلط) ÷ (۳ × کل) × ۱۰۰",
                MARGIN, w.y, w.contentW, 9f, false, GRAY) + 14f

            if (r.sections.isNotEmpty()) {
                w.ensure(40f)
                w.y += w.text("نمودار درصد دروس", MARGIN, w.y, w.contentW, 13f, true, PRIMARY) + 8f
                // bar chart: label column on the right, zero line, bars toward the left
                val labelW = 110f; val valueW = 50f
                val chartRight = PAGE_W - MARGIN - labelW
                val chartLeft = MARGIN + valueW
                val minV = -100.0 / 3; val span = 100.0 - minV
                fun xOf(v: Double) = (chartRight - (v - minV) / span * (chartRight - chartLeft)).toFloat()
                val zeroX = xOf(0.0)
                for (s in r.sections) {
                    w.ensure(22f)
                    w.text(s.section.name, chartRight + 6, w.y + 2, labelW - 6, 10f)
                    fill.color = LIGHT
                    w.canvas.drawRoundRect(RectF(chartLeft, w.y + 4, chartRight, w.y + 16), 6f, 6f, fill)
                    fill.color = if (s.percent >= 0) PRIMARY else RED
                    val x = xOf(s.percent.coerceIn(minV, 100.0))
                    w.canvas.drawRoundRect(RectF(minOf(x, zeroX), w.y + 4, maxOf(x, zeroX), w.y + 16), 6f, 6f, fill)
                    w.text(s.percent.faPercent(), MARGIN, w.y + 2, valueW - 4, 9.5f, true, Color.DKGRAY, Layout.Alignment.ALIGN_OPPOSITE)
                    w.y += 22f
                }
                w.y += 10f

                // table
                val headers = listOf("درس", "تعداد", "صحیح", "غلط", "نزده", "درصد", "درصد خام")
                val widths = listOf(0.26f, 0.11f, 0.11f, 0.11f, 0.11f, 0.15f, 0.15f).map { it * w.contentW }
                fun row(cells: List<String>, header: Boolean, shade: Boolean) {
                    w.ensure(22f)
                    if (header || shade) {
                        fill.color = if (header) PRIMARY else LIGHT
                        w.canvas.drawRect(MARGIN, w.y, PAGE_W - MARGIN, w.y + 22f, fill)
                    }
                    var right = PAGE_W - MARGIN
                    cells.forEachIndexed { i, c ->
                        w.text(c, right - widths[i], w.y + 4, widths[i], 9.5f, header, if (header) Color.WHITE else Color.BLACK,
                            Layout.Alignment.ALIGN_CENTER)
                        right -= widths[i]
                    }
                    w.y += 22f
                }
                row(headers, true, false)
                r.sections.forEachIndexed { i, s ->
                    row(listOf(s.section.name, s.total.fa(), s.correct.fa(), s.wrong.fa(), s.blank.fa(), s.percent.faPercent(), s.rawPercent.faPercent()), false, i % 2 == 1)
                }
                w.y += 14f
            }

            fun outcomeText(list: List<QuestionOutcome>, withStudent: Boolean) = list.joinToString("     ") { o ->
                val st = when (o.student) {
                    Answer.MULTI -> "چندگزینه"
                    Answer.BLANK -> "خالی"
                    else -> o.student.fa()
                }
                if (withStudent) "س${o.question.fa()}: شما ${st}، کلید ${o.key.fa()}" else "س${o.question.fa()} (کلید ${o.key.fa()})"
            }
            w.ensure(30f)
            w.y += w.text("سؤالات غلط (${r.wrongQuestions.size.fa()})", MARGIN, w.y, w.contentW, 13f, true, RED) + 6f
            if (r.wrongQuestions.isEmpty()) w.paragraph("هیچ پاسخ غلطی ندارید. عالی!", 10f, GRAY)
            else w.paragraph(outcomeText(r.wrongQuestions, true), 10f)
            w.y += 12f
            w.ensure(30f)
            w.y += w.text("سؤالات بی‌پاسخ (${r.blankQuestions.size.fa()})", MARGIN, w.y, w.contentW, 13f, true, GRAY) + 6f
            if (r.blankQuestions.isEmpty()) w.paragraph("به همه سؤالات پاسخ داده‌اید.", 10f, GRAY)
            else w.paragraph(outcomeText(r.blankQuestions, false), 10f)
            w.finish()

            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val safe = exam.config.name.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(40).ifBlank { "report" }
            val file = File(dir, "karnameh_${safe}_${PersianDigits.toLatin(exam.id.toString())}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            return file
        } finally {
            doc.close()
        }
    }

    fun shareIntent(file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, "اشتراک‌گذاری کارنامه").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
