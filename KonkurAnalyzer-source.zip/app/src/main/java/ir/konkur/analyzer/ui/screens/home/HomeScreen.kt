package ir.konkur.analyzer.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel

@Composable
fun HomeScreen(flow: ExamFlowViewModel, onNew: () -> Unit, onHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.OfflineBolt, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.height(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("کارنامه‌ساز کنکور", style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
        Text("تحلیل آفلاین آزمون با عکس پاسخنامه و پاسخ‌برگ", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(28.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Text("همه‌چیز روی گوشی شما می‌ماند؛ بدون اینترنت، بدون آپلود عکس‌ها.", modifier = Modifier.padding(16.dp), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  تحلیل آزمون جدید") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.History, null); Text("  تاریخچه و روند پیشرفت") }
        Spacer(Modifier.height(16.dp))
        Text("نسخه ۱ • پردازش تصویر روی دستگاه", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
