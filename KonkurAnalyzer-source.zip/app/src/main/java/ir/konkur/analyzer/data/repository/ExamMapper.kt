package ir.konkur.analyzer.data.repository

import ir.konkur.analyzer.data.db.ExamEntity
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.model.ExamConfig
import ir.konkur.analyzer.domain.model.Section
import ir.konkur.analyzer.domain.model.SheetLayout
import ir.konkur.analyzer.domain.scoring.ScoringEngine

/** Pure string encoding so the DB needs no serialisation library. */
object ExamMapper {
    fun encodeSections(s: List<Section>): String =
        s.joinToString(";") { "${clean(it.name)}|${it.from}|${it.to}" }

    fun decodeSections(s: String): List<Section> =
        if (s.isBlank()) emptyList() else s.split(";").mapNotNull { part ->
            val p = part.split("|")
            if (p.size != 3) null else {
                val f = p[1].toIntOrNull(); val t = p[2].toIntOrNull()
                if (f == null || t == null) null else Section(p[0], f, t)
            }
        }

    fun encodeAnswers(a: List<Int>): String = a.joinToString(",")
    fun decodeAnswers(s: String): List<Int> = if (s.isBlank()) emptyList() else s.split(",").map { it.trim().toIntOrNull() ?: 0 }

    private fun clean(name: String) = name.replace("|", " ").replace(";", " ").trim()

    fun toEntity(e: Exam) = ExamEntity(
        id = e.id,
        name = e.config.name,
        dateMillis = e.config.dateMillis,
        questionCount = e.config.questionCount,
        sections = encodeSections(e.config.sections),
        keyAnswers = encodeAnswers(e.key),
        studentAnswers = encodeAnswers(e.answers),
        optionsLeftToRight = e.config.sheetLayout.optionsLeftToRight,
        blocksRightToLeft = e.config.sheetLayout.blocksRightToLeft,
        correct = e.report.correct,
        wrong = e.report.wrong,
        blank = e.report.blank,
        percent = e.report.percent,
        rawPercent = e.report.rawPercent,
        createdAt = e.createdAt,
    )

    fun toDomain(e: ExamEntity): Exam {
        val sections = decodeSections(e.sections)
        val key = decodeAnswers(e.keyAnswers)
        val answers = decodeAnswers(e.studentAnswers)
        return Exam(
            id = e.id,
            config = ExamConfig(e.name, e.dateMillis, e.questionCount, sections, SheetLayout(e.optionsLeftToRight, e.blocksRightToLeft)),
            key = key,
            answers = answers,
            report = ScoringEngine.grade(key, answers, sections),
            createdAt = e.createdAt,
        )
    }
}
