package ir.konkur.analyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.konkur.analyzer.data.settings.ThemeMode
import ir.konkur.analyzer.ui.navigation.AppNavHost
import ir.konkur.analyzer.ui.theme.KonkurTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as KonkurApp).container
        setContent {
            val mode by container.settings.theme.collectAsStateWithLifecycle()
            val dark = when (mode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            KonkurTheme(darkTheme = dark) {
                AppNavHost(container)
            }
        }
    }
}
