package ir.konkur.analyzer.ui.screens.scan

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.konkur.analyzer.ui.components.BackButton
import ir.konkur.analyzer.ui.components.ErrorCard
import ir.konkur.analyzer.ui.components.Loading
import ir.konkur.analyzer.ui.components.ScreenTitle
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel
import ir.konkur.analyzer.vision.LiveDetection
import ir.konkur.analyzer.vision.LiveDocumentAnalyzer
import ir.konkur.analyzer.vision.ImageLoader
import java.io.File
import java.util.concurrent.Executors

enum class ScanKind { KEY, SHEET }

@Composable
fun ScanScreen(flow: ExamFlowViewModel, kind: ScanKind, onBack: () -> Unit, onReview: () -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current
    var detection by remember { mutableStateOf(LiveDetection(null, .75f, 0f)) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var previewUseCase by remember { mutableStateOf<androidx.camera.core.Preview?>(null) }
    var cameraReady by remember { mutableStateOf(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    var cameraPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val askPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { cameraPermission = it }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runCatching { ImageLoader.fromUri(context, uri) }.onSuccess { bmp -> if (kind == ScanKind.KEY) flow.scanKey(bmp) else flow.scanSheet(bmp) }
            .onFailure { /* scanner screen shows its own recoverable error */ }
    }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }
    LaunchedEffect(cameraPermission) {
        if (!cameraPermission) return@LaunchedEffect
        val provider = ProcessCameraProvider.getInstance(context).get()
        val preview = androidx.camera.core.Preview.Builder().build()
        val cap = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
        val analyzer = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().also {
            it.setAnalyzer(executor, LiveDocumentAnalyzer { detection = it })
        }
        provider.unbindAll()
        provider.bindToLifecycle(lifecycle, CameraSelector.DEFAULT_BACK_CAMERA, preview, cap, analyzer)
        previewUseCase = preview
        capture = cap; cameraReady = true
    }

    val title = if (kind == ScanKind.KEY) "عکس کلید پاسخ" else "عکس پاسخ‌برگ شما"
    val hint = if (kind == ScanKind.KEY) "کلید رسمی را کامل داخل کادر بگذارید" else "پاسخ‌برگ پرشده را صاف و کامل داخل کادر بگذارید"
    LaunchedEffect(detection.isStable) {
        if (detection.isStable && !flow.busy) {
            kotlinx.coroutines.delay(350)
            capture?.let { takePhoto(context, it) { bmp -> if (kind == ScanKind.KEY) flow.scanKey(bmp) else flow.scanSheet(bmp) } }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { BackButton(onBack); ScreenTitle(title) }
        Text(hint, color = Color.Gray)
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.Black)) {
            if (cameraPermission) {
                AndroidView({ PreviewView(it) }, Modifier.fillMaxSize(), update = { pv ->
                    previewUseCase?.setSurfaceProvider(pv.surfaceProvider)
                })
                GuideOverlay(detection)
            } else {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("برای عکس گرفتن، دسترسی دوربین لازم است", color = Color.White)
                    Button({ askPermission.launch(Manifest.permission.CAMERA) }) { Text("فعال‌سازی دوربین") }
                }
            }
            if (flow.busy) Loading("در حال خواندن تصویر…")
        }
        Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant)) { Text("کادر سبز: آماده • دوربین را ثابت نگه دارید تا ثبت خودکار شود. برای نتیجه بهتر نور یکنواخت و بدون سایه باشد.", Modifier.padding(12.dp)) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ pick.launch("image/*") }, Modifier.weight(1f)) { Icon(Icons.Default.PhotoLibrary, null); Text(" از گالری") }
            Button({ capture?.let { takePhoto(context, it) { bmp -> if (kind == ScanKind.KEY) flow.scanKey(bmp) else flow.scanSheet(bmp) } } }, enabled = cameraReady && !flow.busy, modifier = Modifier.weight(1f)) { Icon(Icons.Default.CameraAlt, null); Text(" ثبت عکس") }
        }
        if (flow.error != null) ErrorCard(flow.error!!)
        if (flow.keyPreview != null && kind == ScanKind.KEY || flow.sheetPreview != null && kind == ScanKind.SHEET) Button(onClick = onReview, modifier = Modifier.fillMaxWidth()) { Text("بازبینی نتیجه") }
    }
}

private fun takePhoto(context: android.content.Context, capture: ImageCapture, done: (android.graphics.Bitmap) -> Unit) {
    val file = File(context.cacheDir, "captures/${System.currentTimeMillis()}.jpg").apply { parentFile?.mkdirs() }
    capture.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) { runCatching { ImageLoader.fromUri(context, Uri.fromFile(file)) }.onSuccess(done) }
        override fun onError(exception: ImageCaptureException) {}
    })
}

@Composable private fun GuideOverlay(d: LiveDetection) {
    Canvas(Modifier.fillMaxSize()) {
        val c = d.corners
        if (c == null) drawRoundRect(Color.White.copy(alpha = .5f), style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
        else {
            val p = Path().apply { moveTo(c[0].first * size.width, c[0].second * size.height); for (i in 1 until c.size) lineTo(c[i].first * size.width, c[i].second * size.height); close() }
            drawPath(p, Color(0xFF66BB6A), style = androidx.compose.ui.graphics.drawscope.Stroke(4.dp.toPx()))
        }
    }
}
