package ir.konkur.analyzer.vision

import android.graphics.Bitmap
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Cell
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.roundToInt

data class KeyScanResult(
    val cells: List<Cell>,
    val layout: KeyLayout,
    val recognized: Int,
    val preview: Bitmap?,
    val documentFound: Boolean,
)

/**
 * Reads an answer key photo: Persian digits in a table (rows-of-pairs or column layout).
 * Steps: perspective/skew/lighting normalisation → adaptive binarisation → table-line removal →
 * connected components → per-glyph MLP digit recognition (+ geometric rule for the tiny Persian
 * zero) → tokens → [KeyLayoutParser].
 */
class AnswerKeyScanner(private val classifier: DigitClassifier) {

    private data class Glyph(
        val digit: Int, val conf: Float, val x: Int, val y: Int, val w: Int, val h: Int, val zero: Boolean,
    ) {
        val cy get() = y + h / 2f
    }

    fun scan(bitmap: Bitmap, questionCount: Int): KeyScanResult {
        val prepared = CvImage.prepare(bitmap)
        try {
            val gray = prepared.gray
            val (tokens, m) = extractTokens(gray)
            val parsed = KeyLayoutParser.parse(tokens, m, questionCount)
            val cells = (1..questionCount).map { q ->
                val r = parsed.answers[q]
                if (r == null) Cell(Answer.BLANK, 0f) else Cell(r.first, r.second)
            }
            val preview = runCatching { drawPreview(gray, tokens) }.getOrNull()
            return KeyScanResult(cells, parsed.layout, parsed.answers.size, preview, prepared.documentFound)
        } finally {
            prepared.release()
        }
    }

    /** Returns the recognised tokens and the median digit height. */
    fun extractTokens(gray: Mat): Pair<List<Token>, Float> {
        val h = gray.rows(); val w = gray.cols()
        val bin = Mat()
        Imgproc.adaptiveThreshold(gray, bin, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY_INV, 31, 15.0)

        // Remove ruling lines of the table so digits touching them become free components.
        val hl = Mat(); val vl = Mat()
        val hk = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(max(10, w / 25).toDouble(), 1.0))
        val vk = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(1.0, max(10, h / 25).toDouble()))
        Imgproc.morphologyEx(bin, hl, Imgproc.MORPH_OPEN, hk)
        Imgproc.morphologyEx(bin, vl, Imgproc.MORPH_OPEN, vk)
        Core.bitwise_or(hl, vl, hl)
        Imgproc.dilate(hl, hl, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)))
        Core.bitwise_not(hl, hl)
        val text = Mat()
        Core.bitwise_and(bin, hl, text)
        bin.release(); hl.release(); vl.release(); hk.release(); vk.release()

        val labels = Mat(); val stats = Mat(); val centroids = Mat()
        val n = Imgproc.connectedComponentsWithStats(text, labels, stats, centroids, 8, CvType.CV_32S)
        text.release(); centroids.release()
        if (n <= 1) { labels.release(); stats.release(); return emptyList<Token>() to 0f }
        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        stats.release()
        fun sx(i: Int) = st[i * 5]; fun sy(i: Int) = st[i * 5 + 1]
        fun sw(i: Int) = st[i * 5 + 2]; fun sh(i: Int) = st[i * 5 + 3]; fun sa(i: Int) = st[i * 5 + 4]

        val heights = (1 until n).filter { i ->
            val hh = sh(i)
            hh >= 0.008 * h && hh <= 0.08 * h && sa(i) >= 12 && hh.toFloat() / max(1, sw(i)) in 0.3f..8f
        }.map { sh(it) }.sorted()
        if (heights.isEmpty()) { labels.release(); return emptyList<Token>() to 0f }
        val m = heights[heights.size / 2].toFloat()

        val glyphs = ArrayList<Glyph>()
        for (i in 1 until n) {
            val x = sx(i); val y = sy(i); val cw = sw(i); val ch = sh(i); val a = sa(i)
            if (ch > 1.7f * m || cw > 1.5f * m || a < 0.02f * m * m) continue
            val zeroLike = ch >= 0.12f * m && ch < 0.62f * m &&
                cw.toFloat() / max(1, ch) in 0.5f..2.2f && a >= 0.35f * cw * ch
            if (ch >= 0.45f * m) {
                val p = classifier.predict(glyphVector(labels, i, Rect(x, y, cw, ch)))
                if (ch >= 0.62f * m || (p.digit == 5 && p.confidence > 0.9f)) {
                    // A full-height "zero" is not a Persian digit (it is a letter like «ه» or noise).
                    if (p.digit != 0) glyphs += Glyph(p.digit, p.confidence, x, y, cw, ch, false)
                    continue
                }
            }
            if (zeroLike) glyphs += Glyph(0, 0.8f, x, y, cw, ch, true)
        }
        labels.release()
        return groupTokens(glyphs, m) to m
    }

    private fun glyphVector(labels: Mat, label: Int, r: Rect): FloatArray {
        val roi = labels.submat(r)
        val mask = Mat()
        Core.compare(roi, Scalar(label.toDouble()), mask, Core.CMP_EQ)
        val f = Mat()
        mask.convertTo(f, CvType.CV_32F, 1.0 / 255.0)
        val side = DigitClassifier.INPUT_SIDE
        val s = 20.0 / max(r.width, r.height)
        val nw = max(1, (r.width * s).roundToInt()); val nh = max(1, (r.height * s).roundToInt())
        val small = Mat()
        Imgproc.resize(f, small, Size(nw.toDouble(), nh.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
        val out = Mat.zeros(side, side, CvType.CV_32F)
        val x0 = (side - nw) / 2; val y0 = (side - nh) / 2
        small.copyTo(out.submat(Rect(x0, y0, nw, nh)))
        val v = FloatArray(side * side)
        out.get(0, 0, v)
        roi.release(); mask.release(); f.release(); small.release(); out.release()
        return v
    }

    /** Clusters glyphs into lines, then into horizontally adjacent tokens (numbers are written LTR). */
    private fun groupTokens(glyphs: List<Glyph>, m: Float): List<Token> {
        val sorted = glyphs.sortedBy { it.cy }
        val lines = ArrayList<MutableList<Glyph>>()
        for (g in sorted) {
            val last = lines.lastOrNull()
            val ok = last != null && if (!g.zero) {
                kotlin.math.abs(last.last().cy - g.cy) < 0.6f * m
            } else {
                kotlin.math.abs(last.map { it.cy }.average().toFloat() - g.cy) < 0.7f * m
            }
            if (ok) last!!.add(g) else lines.add(mutableListOf(g))
        }
        val tokens = ArrayList<Token>()
        for (line in lines) {
            line.sortBy { it.x }
            var cur = ArrayList<Glyph>()
            fun flush() {
                var t: List<Glyph> = cur
                while (t.isNotEmpty() && t.first().zero) t = t.drop(1) // no leading zeros in question numbers
                if (t.isNotEmpty() && t.size <= 3) {
                    val value = t.fold(0) { acc, g -> acc * 10 + g.digit }
                    val x0 = t.minOf { it.x }; val x1 = t.maxOf { it.x + it.w }
                    val y0 = t.minOf { it.y }; val y1 = t.maxOf { it.y + it.h }
                    tokens += Token(
                        value, t.size, t.minOf { it.conf },
                        (x0 + x1) / 2f, (y0 + y1) / 2f, (x1 - x0).toFloat(), (y1 - y0).toFloat(),
                    )
                }
                cur = ArrayList()
            }
            for (g in line) {
                val prev = cur.lastOrNull()
                if (prev != null && g.x - (prev.x + prev.w) > 0.55f * m) flush()
                cur.add(g)
            }
            flush()
        }
        return tokens
    }

    private fun drawPreview(gray: Mat, tokens: List<Token>): Bitmap {
        val rgb = Mat()
        Imgproc.cvtColor(gray, rgb, Imgproc.COLOR_GRAY2RGB)
        for (t in tokens) {
            val color = if (t.isAnswerLike) Scalar(30.0, 150.0, 60.0) else Scalar(60.0, 90.0, 220.0)
            Imgproc.rectangle(
                rgb,
                Point((t.cx - t.w / 2 - 2).toDouble(), (t.cy - t.h / 2 - 2).toDouble()),
                Point((t.cx + t.w / 2 + 2).toDouble(), (t.cy + t.h / 2 + 2).toDouble()),
                color, 2,
            )
        }
        return CvImage.grayToBitmap(rgb).also { rgb.release() }
    }
}
