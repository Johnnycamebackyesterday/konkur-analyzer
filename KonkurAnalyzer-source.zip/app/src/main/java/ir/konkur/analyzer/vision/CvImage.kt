package ir.konkur.analyzer.vision

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Image that is ready for analysis: perspective-corrected, deskewed and illumination-flattened. */
class PreparedImage(val gray: Mat, val documentFound: Boolean) {
    fun release() = gray.release()
}

/** OpenCV helpers shared by both scanners and the live camera guide. */
object CvImage {
    const val WORK_MAX_SIDE = 2000

    fun bitmapToGray(bitmap: Bitmap): Mat {
        val src = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val rgba = Mat()
        Utils.bitmapToMat(src, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        return gray
    }

    fun resizeMax(src: Mat, maxSide: Int): Mat {
        val s = maxSide.toDouble() / max(src.cols(), src.rows())
        if (s >= 1.0) return src.clone()
        val dst = Mat()
        Imgproc.resize(src, dst, Size(src.cols() * s, src.rows() * s), 0.0, 0.0, Imgproc.INTER_AREA)
        return dst
    }

    /** Full preprocessing used by both pipelines. */
    fun prepare(bitmap: Bitmap): PreparedImage {
        val full = bitmapToGray(bitmap)
        val gray = resizeMax(full, WORK_MAX_SIDE)
        full.release()
        val quad = DocumentDetector.detect(gray)
        val aligned = if (quad != null) {
            DocumentDetector.warp(gray, quad).also { gray.release() }
        } else {
            deskew(gray).also { if (it !== gray) gray.release() }
        }
        val flat = flattenIllumination(aligned)
        aligned.release()
        return PreparedImage(flat, quad != null)
    }

    /** Divides by a morphological background estimate: removes shadows and uneven lighting. */
    fun flattenIllumination(gray: Mat): Mat {
        val k = max(15, (min(gray.cols(), gray.rows()) / 20) or 1)
        val bg = Mat()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(k.toDouble(), k.toDouble()))
        Imgproc.morphologyEx(gray, bg, Imgproc.MORPH_CLOSE, kernel)
        val out = Mat()
        Core.divide(gray, bg, out, 255.0)
        bg.release(); kernel.release()
        return out
    }

    /** Estimates the dominant text/table skew from long near-horizontal lines and rotates it away. */
    fun deskew(gray: Mat): Mat {
        val bin = Mat()
        Imgproc.adaptiveThreshold(gray, bin, 255.0, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY_INV, 25, 15.0)
        val lines = Mat()
        val minLen = gray.cols() / 6.0
        Imgproc.HoughLinesP(bin, lines, 1.0, Math.PI / 360, 120, minLen, 10.0)
        bin.release()
        val angles = ArrayList<Double>()
        val buf = IntArray(4)
        for (i in 0 until lines.rows()) {
            lines.get(i, 0, buf)
            val a = Math.toDegrees(atan2((buf[3] - buf[1]).toDouble(), (buf[2] - buf[0]).toDouble()))
            if (abs(a) < 15) angles += a
        }
        lines.release()
        if (angles.size < 3) return gray
        angles.sort()
        val angle = angles[angles.size / 2]
        if (abs(angle) < 0.4) return gray
        val center = Point(gray.cols() / 2.0, gray.rows() / 2.0)
        val m = Imgproc.getRotationMatrix2D(center, angle, 1.0)
        val out = Mat()
        Imgproc.warpAffine(gray, out, m, gray.size(), Imgproc.INTER_LINEAR, Core.BORDER_REPLICATE, Scalar(255.0))
        m.release()
        return out
    }

    fun grayToBitmap(gray: Mat, maxSide: Int = 1400): Bitmap {
        val small = resizeMax(gray, maxSide)
        val rgba = Mat()
        when (small.channels()) {
            1 -> Imgproc.cvtColor(small, rgba, Imgproc.COLOR_GRAY2RGBA)
            3 -> Imgproc.cvtColor(small, rgba, Imgproc.COLOR_RGB2RGBA)
            else -> small.copyTo(rgba)
        }
        val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        small.release(); rgba.release()
        return bmp
    }
}

/** Finds the paper sheet (largest convex quadrilateral) in a grayscale image. */
object DocumentDetector {
    private const val DETECT_SIDE = 600.0

    /** Returns corners ordered TL, TR, BR, BL in the coordinates of [gray], or null. */
    fun detect(gray: Mat, minAreaFraction: Double = 0.2): Array<Point>? {
        val s = min(1.0, DETECT_SIDE / max(gray.cols(), gray.rows()))
        val small = Mat()
        Imgproc.resize(gray, small, Size(gray.cols() * s, gray.rows() * s), 0.0, 0.0, Imgproc.INTER_AREA)
        Imgproc.GaussianBlur(small, small, Size(5.0, 5.0), 0.0)
        val edges = Mat()
        Imgproc.Canny(small, edges, 40.0, 120.0)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
        Imgproc.dilate(edges, edges, kernel)
        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(edges, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val imgArea = small.cols().toDouble() * small.rows()
        var best: Array<Point>? = null
        var bestArea = 0.0
        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area < minAreaFraction * imgArea) continue
            val c2f = MatOfPoint2f(*c.toArray())
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(c2f, approx, 0.02 * Imgproc.arcLength(c2f, true), true)
            val pts = approx.toArray()
            if (pts.size == 4 && Imgproc.isContourConvex(MatOfPoint(*pts)) && area > bestArea) {
                best = pts; bestArea = area
            } else if (best == null && area > 0.35 * imgArea) {
                // Rounded or partly occluded corners: fall back to the min-area rectangle.
                val rr = Imgproc.minAreaRect(c2f)
                val box = arrayOfNulls<Point>(4)
                rr.points(box)
                if (rr.size.area() < 1.3 * area) {
                    best = box.requireNoNulls(); bestArea = area * 0.99
                }
            }
            c2f.release(); approx.release()
        }
        contours.forEach { it.release() }
        hierarchy.release(); edges.release(); small.release(); kernel.release()
        val b = best ?: return null
        return order(b.map { Point(it.x / s, it.y / s) }.toTypedArray())
    }

    fun order(p: Array<Point>): Array<Point> {
        val tl = p.minBy { it.x + it.y }
        val br = p.maxBy { it.x + it.y }
        val tr = p.minBy { it.y - it.x }
        val bl = p.maxBy { it.y - it.x }
        return arrayOf(tl, tr, br, bl)
    }

    fun warp(gray: Mat, q: Array<Point>): Mat {
        val (tl, tr, br, bl) = q
        val w = max(hypot(tr.x - tl.x, tr.y - tl.y), hypot(br.x - bl.x, br.y - bl.y)).coerceAtLeast(10.0)
        val h = max(hypot(bl.x - tl.x, bl.y - tl.y), hypot(br.x - tr.x, br.y - tr.y)).coerceAtLeast(10.0)
        val src = MatOfPoint2f(tl, tr, br, bl)
        val dst = MatOfPoint2f(Point(0.0, 0.0), Point(w, 0.0), Point(w, h), Point(0.0, h))
        val m = Imgproc.getPerspectiveTransform(src, dst)
        val out = Mat()
        Imgproc.warpPerspective(gray, out, m, Size(w, h), Imgproc.INTER_LINEAR, Core.BORDER_REPLICATE)
        src.release(); dst.release(); m.release()
        return out
    }

    /** Signed polygon area of normalised corners (0..1 coordinates). */
    fun normalizedArea(q: List<Pair<Float, Float>>): Float {
        var a = 0f
        for (i in q.indices) {
            val (x1, y1) = q[i]
            val (x2, y2) = q[(i + 1) % q.size]
            a += x1 * y2 - x2 * y1
        }
        return abs(a) / 2f
    }

    @Suppress("unused")
    private fun Mat.isGray() = type() == CvType.CV_8UC1
}
