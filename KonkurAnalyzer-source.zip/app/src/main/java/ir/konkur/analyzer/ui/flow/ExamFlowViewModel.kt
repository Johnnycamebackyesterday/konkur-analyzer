package ir.konkur.analyzer.ui.flow

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.konkur.analyzer.core.JalaliCalendar
import ir.konkur.analyzer.di.AppContainer
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Cell
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.model.ExamConfig
import ir.konkur.analyzer.domain.model.Report
import ir.konkur.analyzer.domain.model.Section
import ir.konkur.analyzer.domain.model.SheetLayout
import ir.konkur.analyzer.domain.scoring.ScoringEngine
import ir.konkur.analyzer.vision.KeyLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** State machine for one exam; screens stay dumb and can be recreated without losing the work. */
class ExamFlowViewModel : ViewModel() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var container: AppContainer? = null

    var name by mutableStateOf(""); private set
    var date by mutableStateOf(JalaliCalendar.today()); private set
    var questionCount by mutableStateOf(100); private set
    var sections by mutableStateOf(listOf<Section>()); private set
    var optionsLeftToRight by mutableStateOf(true); private set
    var blocksRightToLeft by mutableStateOf(true); private set
    var keyCells by mutableStateOf(listOf<Cell>()); private set
    var answerCells by mutableStateOf(listOf<Cell>()); private set
    var keyPreview by mutableStateOf<Bitmap?>(null); private set
    var sheetPreview by mutableStateOf<Bitmap?>(null); private set
    var keyLayout by mutableStateOf(KeyLayout.UNKNOWN); private set
    var keyScanMessage by mutableStateOf(""); private set
    var sheetScanMessage by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var report by mutableStateOf<Report?>(null); private set
    var savedId by mutableStateOf(0L); private set

    fun attach(c: AppContainer) { container = c }
    fun reset() {
        name = ""; date = JalaliCalendar.today(); questionCount = 100; sections = emptyList()
        optionsLeftToRight = true; blocksRightToLeft = true; keyCells = emptyList(); answerCells = emptyList()
        keyPreview = null; sheetPreview = null; keyLayout = KeyLayout.UNKNOWN; keyScanMessage = ""; sheetScanMessage = ""
        busy = false; error = null; report = null; savedId = 0L
    }
    fun setName(v: String) { name = v }
    fun setDate(v: ir.konkur.analyzer.core.JalaliDate) { date = v }
    fun setQuestionCount(v: Int) { questionCount = v.coerceIn(1, 400); if (keyCells.isNotEmpty()) keyCells = resize(keyCells); if (answerCells.isNotEmpty()) answerCells = resize(answerCells) }
    fun setSections(v: List<Section>) { sections = v }
    fun setLayout(options: Boolean, blocks: Boolean) { optionsLeftToRight = options; blocksRightToLeft = blocks }
    fun setKeyCell(q: Int, v: Int) { keyCells = update(keyCells, q, v) }
    fun setAnswerCell(q: Int, v: Int) { answerCells = update(answerCells, q, v) }

    fun scanKey(bitmap: Bitmap) {
        container?.let { c ->
            busy = true; error = null
            scope.launch {
                val result = c.scanAnswerKey(bitmap, questionCount)
                result.onSuccess { r -> keyCells = r.cells; keyLayout = r.layout; keyPreview = r.preview; keyScanMessage = "${r.recognized} پاسخ از ${questionCount} سؤال خوانده شد" }
                    .onFailure { error = "عکس کلید قابل خواندن نبود: ${it.message ?: "عکس واضح‌تری بگیرید"}" }
                busy = false
            }
        }
    }

    fun scanSheet(bitmap: Bitmap) {
        container?.let { c ->
            busy = true; error = null
            scope.launch {
                val result = c.scanAnswerSheet(bitmap, questionCount, SheetLayout(optionsLeftToRight, blocksRightToLeft))
                result.onSuccess { r -> answerCells = r.cells; sheetPreview = r.preview; sheetScanMessage = "${r.questionsFound} سؤال از روی ${r.bubblesFound} حباب پیدا شد" }
                    .onFailure { error = "عکس پاسخ‌برگ قابل خواندن نبود: ${it.message ?: "عکس واضح‌تری بگیرید"}" }
                busy = false
            }
        }
    }

    fun calculate() {
        if (keyCells.size != questionCount || answerCells.size != questionCount) {
            error = "ابتدا هر دو برگه را اسکن و بررسی کنید"; return
        }
        report = ScoringEngine.grade(keyCells.map { it.value }, answerCells.map { it.value }, sections)
    }

    fun save(onDone: () -> Unit) {
        val c = container ?: return
        val r = report ?: run { calculate(); report } ?: return
        busy = true
        scope.launch {
            savedId = c.saveExam(
                ExamConfig(name.ifBlank { "آزمون بدون نام" }, JalaliCalendar.toMillis(date), questionCount, sections, SheetLayout(optionsLeftToRight, blocksRightToLeft)),
                keyCells.map { it.value }, answerCells.map { it.value }, savedId,
            )
            busy = false; onDone()
        }
    }

    fun load(id: Long, onDone: () -> Unit = {}) {
        val c = container ?: return
        scope.launch {
            val e = c.getExam(id) ?: return@launch
            name = e.config.name; date = JalaliCalendar.fromMillis(e.config.dateMillis); questionCount = e.config.questionCount
            sections = e.config.sections; optionsLeftToRight = e.config.sheetLayout.optionsLeftToRight; blocksRightToLeft = e.config.sheetLayout.blocksRightToLeft
            keyCells = e.key.map { Cell(it) }; answerCells = e.answers.map { Cell(it) }; report = e.report; savedId = e.id
            onDone()
        }
    }

    private fun update(list: List<Cell>, q: Int, v: Int): List<Cell> {
        val a = if (list.size == questionCount) list.toMutableList() else MutableList(questionCount) { Cell(Answer.BLANK, 0f) }
        if (q in 1..questionCount) a[q - 1] = Cell(v, 1f, edited = true)
        return a
    }
    private fun resize(list: List<Cell>): List<Cell> = (0 until questionCount).map { list.getOrElse(it) { Cell(Answer.BLANK, 0f) } }

    companion object {
        @Composable
        fun remember(container: AppContainer): ExamFlowViewModel {
            val vm: ExamFlowViewModel = viewModel()
            vm.attach(container)
            return vm
        }
    }
}
