package ir.konkur.analyzer.ui.screens.review

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import ir.konkur.analyzer.core.fa
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Cell
import ir.konkur.analyzer.ui.components.BackButton
import ir.konkur.analyzer.ui.components.ConfidenceLegend
import ir.konkur.analyzer.ui.components.PrimaryButton
import ir.konkur.analyzer.ui.components.ScreenTitle
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel


enum class ReviewKind { KEY, SHEET }

@Composable
fun ReviewScreen(flow: ExamFlowViewModel, kind: ReviewKind, onBack: () -> Unit, onNext: () -> Unit) {
    val cells = if (kind == ReviewKind.KEY) flow.keyCells else flow.answerCells
    val preview = if (kind == ReviewKind.KEY) flow.keyPreview else flow.sheetPreview
    var selected by remember { mutableStateOf<Int?>(null) }
    var dialogQ by remember { mutableStateOf<Int?>(null) }
    val title = if (kind == ReviewKind.KEY) "بازبینی کلید پاسخ" else "بازبینی پاسخ‌های شما"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { BackButton(onBack); ScreenTitle(title) }
        Text(if (kind == ReviewKind.KEY) "هر خانه قابل ویرایش است. سؤال‌های نارنجی را جدی‌تر بررسی کنید." else "گزینه‌های نارنجی اطمینان پایین دارند؛ با لمس هر خانه اصلاح کنید.", color = Color.Gray)
        if (preview != null) androidx.compose.foundation.Image(preview.asImageBitmap(), null, Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
        ConfidenceLegend()
        if (cells.isEmpty()) Text("چیزی برای نمایش نیست. از بازگشت، عکس را دوباره بگیرید.")
        else {
            val cols = 5
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                cells.indices.chunked(cols).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        row.forEach { index ->
                            val q = index + 1
                            CellBox(q, cells[index], kind, onClick = { dialogQ = q }, Modifier.weight(1f))
                        }
                        repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onBack) { Text("بازگشت") }; PrimaryButton(if (kind == ReviewKind.KEY) "تأیید کلید و اسکن پاسخ‌برگ" else "ساخت کارنامه", onNext, modifier = Modifier.weight(1f)) }
    }
    if (dialogQ != null) {
        val q = dialogQ!!; val current = cells.getOrNull(q - 1) ?: Cell(0)
        AnswerDialog(q, current.value, kind == ReviewKind.KEY, onDismiss = { dialogQ = null }) { v -> if (kind == ReviewKind.KEY) flow.setKeyCell(q, v) else flow.setAnswerCell(q, v); dialogQ = null }
    }
}

@Composable private fun CellBox(q: Int, cell: Cell, kind: ReviewKind, onClick: () -> Unit, modifier: Modifier) {
    val bg = when {
        cell.isLowConfidence -> Color(0xFFFFB74D).copy(alpha = .28f)
        cell.value == Answer.MULTI -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Column(modifier.padding(2.dp).clip(RoundedCornerShape(8.dp)).background(bg).border(1.dp, if (cell.isLowConfidence) Color(0xFFEF6C00) else Color.Transparent, RoundedCornerShape(8.dp)).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(q.fa(), style = MaterialTheme.typography.labelSmall)
        FilterChip(selected = cell.value in 1..4, onClick = onClick, label = { Text(if (cell.value == 0) "خالی" else if (cell.value == -1) "چند" else cell.value.fa()) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable private fun AnswerDialog(q: Int, current: Int, key: Boolean, onDismiss: () -> Unit, onSet: (Int) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("سؤال ${q.fa()}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (key) "گزینه صحیح را انتخاب کنید" else "پاسخ خودتان را انتخاب کنید")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(0, 1, 2, 3, 4, -1).forEach { v -> FilterChip(selected = current == v, onClick = { onSet(v) }, label = { Text(when (v) { 0 -> "خالی"; -1 -> "چندگزینه"; else -> v.fa() }) }) }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } })
}
