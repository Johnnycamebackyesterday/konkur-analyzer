package ir.konkur.analyzer

import android.app.Application
import android.util.Log
import ir.konkur.analyzer.di.AppContainer
import org.opencv.android.OpenCVLoader

class KonkurApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        val cvOk = runCatching { OpenCVLoader.initLocal() }.getOrElse {
            Log.e("KonkurApp", "OpenCV init failed", it); false
        }
        container = AppContainer(this, cvOk)
    }
}
