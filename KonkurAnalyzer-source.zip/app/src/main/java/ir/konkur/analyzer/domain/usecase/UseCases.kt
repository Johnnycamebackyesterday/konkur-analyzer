package ir.konkur.analyzer.domain.usecase

import android.graphics.Bitmap
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.model.ExamConfig
import ir.konkur.analyzer.domain.model.ExamSummary
import ir.konkur.analyzer.domain.model.Report
import ir.konkur.analyzer.domain.model.Section
import ir.konkur.analyzer.domain.model.SheetLayout
import ir.konkur.analyzer.domain.repository.ExamRepository
import ir.konkur.analyzer.domain.scoring.ScoringEngine
import ir.konkur.analyzer.vision.AnswerKeyScanner
import ir.konkur.analyzer.vision.AnswerSheetScanner
import ir.konkur.analyzer.vision.KeyScanResult
import ir.konkur.analyzer.vision.SheetScanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GradeExamUseCase {
    operator fun invoke(key: List<Int>, answers: List<Int>, sections: List<Section>): Report =
        ScoringEngine.grade(key, answers, sections)
}

class SaveExamUseCase(private val repo: ExamRepository, private val grade: GradeExamUseCase) {
    suspend operator fun invoke(config: ExamConfig, key: List<Int>, answers: List<Int>, existingId: Long = 0): Long {
        val report = grade(key, answers, config.sections)
        return repo.save(Exam(id = existingId, config = config, key = key, answers = answers, report = report))
    }
}

class GetExamUseCase(private val repo: ExamRepository) {
    suspend operator fun invoke(id: Long): Exam? = repo.get(id)
}

class DeleteExamUseCase(private val repo: ExamRepository) {
    suspend operator fun invoke(id: Long) = repo.delete(id)
}

class ObserveHistoryUseCase(private val repo: ExamRepository) {
    operator fun invoke(): Flow<List<ExamSummary>> = repo.observeAll().map { exams ->
        exams.sortedWith(compareBy<Exam> { it.config.dateMillis }.thenBy { it.createdAt }).map { e ->
            ExamSummary(
                id = e.id,
                name = e.config.name,
                dateMillis = e.config.dateMillis,
                total = e.report.total,
                correct = e.report.correct,
                wrong = e.report.wrong,
                blank = e.report.blank,
                percent = e.report.percent,
                rawPercent = e.report.rawPercent,
                sectionPercents = e.report.sections.associate { it.section.name to it.percent },
            )
        }
    }
}

/** Runs the answer-key pipeline off the main thread and never throws. */
class ScanAnswerKeyUseCase(private val scanner: () -> AnswerKeyScanner) {
    suspend operator fun invoke(bitmap: Bitmap, questionCount: Int): Result<KeyScanResult> =
        withContext(Dispatchers.Default) { runCatching { scanner().scan(bitmap, questionCount) } }
}

class ScanAnswerSheetUseCase(private val scanner: () -> AnswerSheetScanner) {
    suspend operator fun invoke(bitmap: Bitmap, questionCount: Int, layout: SheetLayout): Result<SheetScanResult> =
        withContext(Dispatchers.Default) { runCatching { scanner().scan(bitmap, questionCount, layout) } }
}
