package ir.konkur.analyzer.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.konkur.analyzer.core.fa
import ir.konkur.analyzer.core.faPercent
import ir.konkur.analyzer.ui.theme.KColors

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Text(title, style = androidx.compose.material3.MaterialTheme.typography.headlineMedium, modifier = Modifier.fillMaxWidth())
    if (subtitle != null) Text(subtitle, color = Color.Gray, modifier = Modifier.padding(top = 4.dp).fillMaxWidth())
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth()) { Text(text) }
}

@Composable
fun BackButton(onClick: () -> Unit) { OutlinedButton(onClick = onClick) { Text("بازگشت") } }

@Composable
fun Loading(message: String = "در حال پردازش…") {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(); Spacer(Modifier.height(12.dp)); Text(message) }
    }
}

@Composable
fun ErrorCard(message: String, onRetry: (() -> Unit)? = null) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null)
            Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text("مشکلی پیش آمد", style = MaterialTheme.typography.titleMedium); Text(message) }
            if (onRetry != null) OutlinedButton(onClick = onRetry) { Text("تلاش دوباره") }
        }
    }
}

@Composable
fun StatusCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.11f))) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(value, style = MaterialTheme.typography.titleLarge, color = color); Text(title, textAlign = TextAlign.Center) }
    }
}

@Composable
fun ScoreSummary(correct: Int, wrong: Int, blank: Int, percent: Double, raw: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatusCard("درصد", percent.faPercent(), androidx.compose.material3.MaterialTheme.colorScheme.primary, Modifier.weight(1f))
        StatusCard("صحیح", correct.fa(), KColors.Correct, Modifier.weight(1f))
        StatusCard("غلط", wrong.fa(), KColors.Wrong, Modifier.weight(1f))
        StatusCard("نزده", blank.fa(), KColors.Blank, Modifier.weight(1f))
    }
    Text("درصد خام: ${raw.faPercent()}", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center)
}

@Composable
fun ConfidenceLegend() {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Info, null, tint = androidx.compose.material3.MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
        Text("خانه‌های نارنجی یعنی اطمینان پایین‌تر؛ حتماً آن‌ها را بررسی کنید.", color = Color.Gray)
    }
}
