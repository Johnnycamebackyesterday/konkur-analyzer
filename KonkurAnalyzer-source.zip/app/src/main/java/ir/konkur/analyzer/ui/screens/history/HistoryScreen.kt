package ir.konkur.analyzer.ui.screens.history

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ir.konkur.analyzer.core.JalaliCalendar
import ir.konkur.analyzer.core.fa
import ir.konkur.analyzer.core.faPercent
import ir.konkur.analyzer.di.AppContainer
import ir.konkur.analyzer.domain.model.ExamSummary
import ir.konkur.analyzer.ui.components.BackButton
import ir.konkur.analyzer.ui.components.ScreenTitle

@Composable
fun HistoryScreen(container: AppContainer, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val list by container.observeHistory().collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { BackButton(onBack); ScreenTitle("تاریخچه آزمون‌ها") }
        if (list.isNotEmpty()) TrendChart(list)
        if (list.isEmpty()) Text("هنوز آزمونی ذخیره نشده است.", color = Color.Gray)
        list.asReversed().forEach { e ->
            Card(onClick = { onOpen(e.id) }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(e.name, style = MaterialTheme.typography.titleMedium); Text(e.percent.faPercent(), color = MaterialTheme.colorScheme.primary) }
                    Text(JalaliCalendar.fromMillis(e.dateMillis).formatLong(), color = Color.Gray)
                    Spacer(Modifier.height(4.dp)); Text("صحیح ${e.correct.fa()} • غلط ${e.wrong.fa()} • نزده ${e.blank.fa()}")
                }
            }
        }
    }
}

@Composable private fun TrendChart(list: List<ExamSummary>) {
    Text("روند درصد آزمون‌ها", style = MaterialTheme.typography.titleLarge)
    Canvas(Modifier.fillMaxWidth().height(150.dp).padding(horizontal = 12.dp)) {
        if (list.size < 1) return@Canvas
        val min = -33.3; val max = 100.0; val w = size.width; val h = size.height
        val points = list.mapIndexed { i, e -> Offset(if (list.size == 1) w/2 else i.toFloat()/(list.size-1)*w, (h - ((e.percent-min)/(max-min)*h)).toFloat().coerceIn(0f,h)) }
        drawLine(Color.Gray, Offset(0f, h * ((max-0)/(max-min)).toFloat()), Offset(w, h * ((max-0)/(max-min)).toFloat()), 1f)
        points.zipWithNext().forEach { (a,b) -> drawLine(Color(0xFF3F51B5), a, b, 4f) }
        points.forEach { drawCircle(Color(0xFF3F51B5), 6f, it) }
    }
}
