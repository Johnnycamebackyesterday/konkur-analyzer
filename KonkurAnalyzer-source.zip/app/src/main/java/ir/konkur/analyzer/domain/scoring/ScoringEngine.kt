package ir.konkur.analyzer.domain.scoring

import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.QuestionOutcome
import ir.konkur.analyzer.domain.model.Report
import ir.konkur.analyzer.domain.model.Section
import ir.konkur.analyzer.domain.model.SectionReport

/**
 * Pure Konkur scoring.
 * - A key value outside 1..4 means the question is cancelled and excluded from the total.
 * - A multi-marked answer counts as wrong (it receives the negative mark).
 * - percent = (3 × correct − wrong) / (3 × total) × 100  (may be negative, minimum −33.3).
 */
object ScoringEngine {

    fun percent(correct: Int, wrong: Int, total: Int): Double =
        if (total <= 0) 0.0 else (3.0 * correct - wrong) / (3.0 * total) * 100.0

    fun rawPercent(correct: Int, total: Int): Double =
        if (total <= 0) 0.0 else correct * 100.0 / total

    fun grade(key: List<Int>, answers: List<Int>, sections: List<Section>): Report {
        val n = key.size
        var correct = 0
        var wrong = 0
        var blank = 0
        var cancelled = 0
        val wrongQ = ArrayList<QuestionOutcome>()
        val blankQ = ArrayList<QuestionOutcome>()
        for (i in 0 until n) {
            val k = key[i]
            val a = answers.getOrElse(i) { Answer.BLANK }
            val q = i + 1
            when {
                !Answer.isOption(k) -> cancelled++
                a == k -> correct++
                a == Answer.BLANK -> { blank++; blankQ += QuestionOutcome(q, a, k) }
                else -> { wrong++; wrongQ += QuestionOutcome(q, a, k) }
            }
        }
        val total = n - cancelled
        val sectionReports = sections.filter { it.size > 0 }.map { gradeSection(key, answers, it) }
        return Report(
            total = total,
            correct = correct,
            wrong = wrong,
            blank = blank,
            cancelled = cancelled,
            percent = percent(correct, wrong, total),
            rawPercent = rawPercent(correct, total),
            sections = sectionReports,
            wrongQuestions = wrongQ,
            blankQuestions = blankQ,
        )
    }

    fun gradeSection(key: List<Int>, answers: List<Int>, s: Section): SectionReport {
        var c = 0
        var w = 0
        var b = 0
        var t = 0
        for (q in s.from..s.to) {
            val k = key.getOrElse(q - 1) { Answer.BLANK }
            if (!Answer.isOption(k)) continue
            t++
            val a = answers.getOrElse(q - 1) { Answer.BLANK }
            when {
                a == k -> c++
                a == Answer.BLANK -> b++
                else -> w++
            }
        }
        return SectionReport(s, t, c, w, b, percent(c, w, t), rawPercent(c, t))
    }

    /** Validates section ranges; returns a Persian error message or null if valid. */
    fun validateSections(sections: List<Section>, questionCount: Int): String? {
        val sorted = sections.sortedBy { it.from }
        for (s in sorted) {
            if (s.name.isBlank()) return "نام همه درس‌ها را وارد کنید"
            if (s.from < 1 || s.to > questionCount || s.from > s.to)
                return "بازه سؤالات «${s.name}» نامعتبر است"
        }
        for (i in 1 until sorted.size) {
            if (sorted[i].from <= sorted[i - 1].to)
                return "بازه «${sorted[i - 1].name}» و «${sorted[i].name}» هم‌پوشانی دارند"
        }
        return null
    }
}
