package ir.konkur.analyzer.domain.model

/** Value of one answer cell. */
object Answer {
    const val BLANK = 0          // student: no mark / key: unknown or cancelled question
    const val MULTI = -1         // student: more than one bubble filled
    fun isOption(v: Int) = v in 1..4
}

data class Section(val name: String, val from: Int, val to: Int) {
    val size: Int get() = (to - from + 1).coerceAtLeast(0)
    operator fun contains(q: Int) = q in from..to
}

/** Physical layout options of the student's answer sheet. */
data class SheetLayout(
    val optionsLeftToRight: Boolean = true,
    val blocksRightToLeft: Boolean = true,
)

data class ExamConfig(
    val name: String,
    val dateMillis: Long,
    val questionCount: Int,
    val sections: List<Section> = emptyList(),
    val sheetLayout: SheetLayout = SheetLayout(),
)

/** One recognised/edited cell; [confidence] in 0..1, cells under [LOW_CONFIDENCE] are highlighted. */
data class Cell(val value: Int, val confidence: Float = 1f, val edited: Boolean = false) {
    val isLowConfidence: Boolean get() = !edited && confidence < LOW_CONFIDENCE

    companion object {
        const val LOW_CONFIDENCE = 0.6f
        val EMPTY_MANUAL = Cell(Answer.BLANK, 1f, edited = true)
    }
}

data class QuestionOutcome(val question: Int, val student: Int, val key: Int)

data class SectionReport(
    val section: Section,
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val percent: Double,
    val rawPercent: Double,
)

data class Report(
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val cancelled: Int,
    /** Konkur negative-marking percentage: (3c - w) / 3T * 100. */
    val percent: Double,
    /** c / T * 100. */
    val rawPercent: Double,
    val sections: List<SectionReport>,
    val wrongQuestions: List<QuestionOutcome>,
    val blankQuestions: List<QuestionOutcome>,
)

data class Exam(
    val id: Long = 0,
    val config: ExamConfig,
    val key: List<Int>,
    val answers: List<Int>,
    val report: Report,
    val createdAt: Long = System.currentTimeMillis(),
)

/** Lightweight row for history lists and trend charts. */
data class ExamSummary(
    val id: Long,
    val name: String,
    val dateMillis: Long,
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val percent: Double,
    val rawPercent: Double,
    val sectionPercents: Map<String, Double>,
)
