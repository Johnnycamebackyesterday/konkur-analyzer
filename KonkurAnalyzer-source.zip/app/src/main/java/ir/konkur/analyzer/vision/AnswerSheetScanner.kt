package ir.konkur.analyzer.vision

import android.graphics.Bitmap
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Cell
import ir.konkur.analyzer.domain.model.SheetLayout
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max

data class SheetScanResult(
    val cells: List<Cell>,
    val bubblesFound: Int,
    val questionsFound: Int,
    val threshold: Float,
    val preview: Bitmap?,
    val documentFound: Boolean,
)

/**
 * Reads a filled multiple-choice answer sheet.
 * Steps: sheet detection + perspective correction → illumination flattening → bubble candidates
 * from contours (size / aspect / circularity) → size consensus → rows → groups of 4 → question
 * blocks ordered per [SheetLayout] → fill ratio per bubble → [BubbleClassifier].
 */
class AnswerSheetScanner {

    fun scan(bitmap: Bitmap, questionCount: Int, layout: SheetLayout): SheetScanResult {
        val prepared = CvImage.prepare(bitmap)
        try {
            return analyze(prepared.gray, questionCount, layout, prepared.documentFound)
        } finally {
            prepared.release()
        }
    }

    fun analyze(gray: Mat, questionCount: Int, layout: SheetLayout, documentFound: Boolean): SheetScanResult {
        val bubbles = findBubbles(gray)
        if (bubbles.size < 4) {
            return SheetScanResult(List(questionCount) { Cell(Answer.BLANK, 0f) }, bubbles.size, 0, 0f, null, documentFound)
        }
        val mw = median(bubbles.map { it.width.toFloat() })
        val mh = median(bubbles.map { it.height.toFloat() })

        // rows → groups of 4 options
        val rows = KeyLayoutParser.cluster(bubbles, 0.5f * mh) { it.y + it.height / 2f }
        val questions = ArrayList<List<Rect>>()
        for (row in rows) {
            val r = row.sortedBy { it.x }
            if (r.size < 4) continue
            val gaps = (0 until r.size - 1).map { (r[it + 1].x - (r[it].x + r[it].width)).toFloat() }
            val small = gaps.sorted().take(max(1, gaps.size * 3 / 4))
            val ig = median(small)
            var cur = ArrayList<Rect>()
            val groups = ArrayList<List<Rect>>()
            for (i in r.indices) {
                if (i > 0 && gaps[i - 1] > max(1.8f * ig, ig + 0.6f * mw)) { groups += cur; cur = ArrayList() }
                cur += r[i]
            }
            groups += cur
            for (g in groups) if (g.size % 4 == 0) for (k in g.indices step 4) questions += g.subList(k, k + 4)
        }
        if (questions.isEmpty()) {
            return SheetScanResult(List(questionCount) { Cell(Answer.BLANK, 0f) }, bubbles.size, 0, 0f, null, documentFound)
        }

        // fill ratios on an Otsu-binarised image
        val bin = Mat()
        Imgproc.threshold(gray, bin, 0.0, 255.0, Imgproc.THRESH_BINARY_INV or Imgproc.THRESH_OTSU)
        val fills = questions.map { q -> FloatArray(4) { fillRatio(bin, q[it]) } }
        bin.release()
        val threshold = BubbleClassifier.globalThreshold(fills.flatMap { it.toList() }.toFloatArray())

        // block columns → reading order
        val idx = questions.indices.toList()
        val blocks = KeyLayoutParser.cluster(idx, 2f * mw) { i -> questions[i].map { it.x }.average().toFloat() }
            .let { b ->
                if (layout.blocksRightToLeft) b.sortedByDescending { g -> g.map { questions[it][0].x }.average() }
                else b.sortedBy { g -> g.map { questions[it][0].x }.average() }
            }
        val order = blocks.flatMap { g -> g.sortedBy { questions[it][0].y } }

        val cells = ArrayList<Cell>(questionCount)
        val decisions = HashMap<Int, BubbleDecision>()
        for (q in 0 until questionCount) {
            val qi = order.getOrNull(q)
            if (qi == null) { cells += Cell(Answer.BLANK, 0f); continue }
            val f = fills[qi]
            val ordered = if (layout.optionsLeftToRight) f else f.reversedArray()
            val d = BubbleClassifier.classify(ordered, threshold)
            decisions[qi] = d
            cells += Cell(d.value, d.confidence)
        }
        val preview = runCatching { drawPreview(gray, questions, decisions, layout) }.getOrNull()
        return SheetScanResult(cells, bubbles.size, questions.size, threshold, preview, documentFound)
    }

    private fun findBubbles(gray: Mat): List<Rect> {
        val w = gray.cols()
        val bin = Mat()
        Imgproc.adaptiveThreshold(gray, bin, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY_INV, 41, 12.0)
        val contours = ArrayList<MatOfPoint>()
        val hier = Mat()
        Imgproc.findContours(bin, contours, hier, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
        bin.release(); hier.release()
        val minS = 0.006 * w; val maxS = 0.08 * w
        val cand = ArrayList<Rect>()
        for (c in contours) {
            val r = Imgproc.boundingRect(c)
            if (r.width < minS || r.height < minS || r.width > maxS || r.height > maxS) { c.release(); continue }
            val ar = r.width.toDouble() / r.height
            if (ar < 0.7 || ar > 2.6) { c.release(); continue }
            val area = Imgproc.contourArea(c)
            val c2f = MatOfPoint2f(*c.toArray())
            val per = Imgproc.arcLength(c2f, true)
            c2f.release(); c.release()
            val circ = 4 * PI * area / (per * per + 1e-6)
            if (circ >= 0.6) cand += r
        }
        if (cand.isEmpty()) return cand
        val mw = median(cand.map { it.width.toFloat() })
        val mh = median(cand.map { it.height.toFloat() })
        val sized = cand.filter { it.width.toFloat() in (0.7f * mw)..(1.3f * mw) && it.height.toFloat() in (0.7f * mh)..(1.3f * mh) }
        // de-duplicate nested contours (outer/inner edge of the same ring)
        val keep = ArrayList<Rect>()
        for (r in sized.sortedByDescending { it.area() }) {
            val cx = r.x + r.width / 2f; val cy = r.y + r.height / 2f
            if (keep.none { abs(cx - (it.x + it.width / 2f)) <= 0.5f * mw && abs(cy - (it.y + it.height / 2f)) <= 0.5f * mh }) keep += r
        }
        return keep
    }

    private fun fillRatio(bin: Mat, r: Rect): Float {
        val safe = Rect(r.x.coerceAtLeast(0), r.y.coerceAtLeast(0),
            r.width.coerceAtMost(bin.cols() - r.x.coerceAtLeast(0)), r.height.coerceAtMost(bin.rows() - r.y.coerceAtLeast(0)))
        if (safe.width <= 2 || safe.height <= 2) return 0f
        val mask = Mat.zeros(safe.height, safe.width, CvType.CV_8UC1)
        Imgproc.ellipse(
            mask, Point(safe.width / 2.0, safe.height / 2.0),
            Size(max(1.0, safe.width * 0.34), max(1.0, safe.height * 0.32)), 0.0, 0.0, 360.0, Scalar(255.0), -1,
        )
        val total = Core.countNonZero(mask)
        val roi = bin.submat(safe)
        val inter = Mat()
        Core.bitwise_and(roi, mask, inter)
        val ink = Core.countNonZero(inter)
        mask.release(); roi.release(); inter.release()
        return if (total == 0) 0f else ink.toFloat() / total
    }

    private fun drawPreview(gray: Mat, questions: List<List<Rect>>, decisions: Map<Int, BubbleDecision>, layout: SheetLayout): Bitmap {
        val rgb = Mat()
        Imgproc.cvtColor(gray, rgb, Imgproc.COLOR_GRAY2RGB)
        for ((qi, q) in questions.withIndex()) {
            val d = decisions[qi]
            for ((oi, r) in q.withIndex()) {
                val option = if (layout.optionsLeftToRight) oi + 1 else 4 - oi
                val color = when {
                    d == null -> Scalar(160.0, 160.0, 160.0)
                    d.value == Answer.MULTI -> Scalar(230.0, 120.0, 0.0)
                    d.value == option -> if (d.confidence < Cell.LOW_CONFIDENCE) Scalar(230.0, 40.0, 40.0) else Scalar(30.0, 160.0, 60.0)
                    else -> Scalar(70.0, 110.0, 230.0)
                }
                Imgproc.rectangle(rgb, r.tl(), r.br(), color, if (d != null && d.value == option) 3 else 1)
            }
        }
        return CvImage.grayToBitmap(rgb).also { rgb.release() }
    }

    private fun median(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        return s[s.size / 2]
    }
}
