package ir.konkur.analyzer.vision

import kotlin.math.abs
import kotlin.math.roundToInt

/** A recognised number token (one or more digits grouped horizontally). */
data class Token(
    val value: Int,
    val digits: Int,
    val confidence: Float,
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
) {
    val isAnswerLike: Boolean get() = digits == 1 && value in 1..4
}

enum class KeyLayout { ROWS_OF_PAIRS, COLUMNS, UNKNOWN }

data class ParsedKey(val answers: Map<Int, Pair<Int, Float>>, val layout: KeyLayout)

/**
 * Pure layout analysis for answer keys. Two hypotheses are evaluated and the one explaining more
 * questions wins:
 *  A) ROWS_OF_PAIRS: vertical columns of question numbers, each next to a column of answers
 *     (classic «شماره | پاسخ» tables, any number of blocks).
 *  B) COLUMNS: horizontal lines of question numbers with the answers in the line below
 *     (transposed tables).
 * Question numbers are not read one by one: a robust line fit (RANSAC) of number versus position
 * along each number column/line infers the question of each answer cell, which tolerates misread
 * or missing number tokens (e.g. the tiny Persian zero).
 */
object KeyLayoutParser {

    fun parse(tokens: List<Token>, digitHeight: Float, questionCount: Int): ParsedKey {
        if (tokens.isEmpty() || digitHeight <= 0f) return ParsedKey(emptyMap(), KeyLayout.UNKNOWN)
        val m = digitHeight
        val a = parseColumns(tokens, m, questionCount)
        val b = parseRows(tokens, m, questionCount)
        return when {
            a.isEmpty() && b.isEmpty() -> ParsedKey(emptyMap(), KeyLayout.UNKNOWN)
            a.size >= b.size -> ParsedKey(a, KeyLayout.ROWS_OF_PAIRS)
            else -> ParsedKey(b, KeyLayout.COLUMNS)
        }
    }

    // ---- hypothesis A -------------------------------------------------------------------------
    private fun parseColumns(tokens: List<Token>, m: Float, n: Int): Map<Int, Pair<Int, Float>> {
        val cols = cluster(tokens, 0.9f * m) { it.cx }.map { c -> c.sortedBy { it.cy } }
        val numberCols = cols.filter { seqScore(it.map { t -> t.value }) >= 0.5f }
        val answerCols = cols.filter { isAnswerLine(it) }
        val res = HashMap<Int, Pair<Int, Float>>()
        for (ac in answerCols) {
            val ax = ac.map { it.cx }.average()
            val right = numberCols.filter { c -> c.map { it.cx }.average() > ax }
            val candidates = right.ifEmpty { numberCols }
            val nc = candidates.minByOrNull { c -> abs(c.map { it.cx }.average() - ax) } ?: continue
            assign(ac, nc, { it.cy }, n, m, res)
        }
        return res
    }

    // ---- hypothesis B -------------------------------------------------------------------------
    private fun parseRows(tokens: List<Token>, m: Float, n: Int): Map<Int, Pair<Int, Float>> {
        val rows = cluster(tokens, 0.6f * m) { it.cy }
            .map { r -> r.sortedByDescending { it.cx } }
            .sortedBy { r -> r.map { it.cy }.average() }
        val res = HashMap<Int, Pair<Int, Float>>()
        for (i in 1 until rows.size) {
            val r = rows[i]
            if (!isAnswerLine(r)) continue
            val numberRow = rows.subList(0, i).lastOrNull { p ->
                val v = p.map { it.value }
                maxOf(seqScore(v), seqScore(v.reversed())) >= 0.5f
            } ?: continue
            assign(r, numberRow, { it.cx }, n, m, res)
        }
        return res
    }

    // ---- helpers ------------------------------------------------------------------------------
    private fun assign(
        answers: List<Token>,
        numbers: List<Token>,
        pos: (Token) -> Float,
        n: Int,
        m: Float,
        res: MutableMap<Int, Pair<Int, Float>>,
    ) {
        val fit = fitLine(numbers, pos, n) ?: return
        for (t in answers) {
            if (!t.isAnswerLike) continue
            val q = (fit.a + fit.b * pos(t)).roundToInt()
            if (q !in 1..n) continue
            val near = fit.inliers.firstOrNull { it.value == q && abs(pos(it) - pos(t)) < 0.8f * m }
            val conf = if (near != null) minOf(t.confidence, near.confidence) else minOf(t.confidence, 0.55f)
            val prev = res[q]
            if (prev == null || prev.second < conf) res[q] = t.value to conf
        }
    }

    class LineFit(val a: Double, val b: Double, val inliers: List<Token>)

    /** RANSAC over all token pairs, then least-squares refinement on the inliers. */
    fun fitLine(tokens: List<Token>, pos: (Token) -> Float, n: Int): LineFit? {
        val c = tokens.filter { it.value in 1..n }
        if (c.size < 3) return null
        var bestA = 0.0
        var bestB = 0.0
        var bestInliers: List<Token> = emptyList()
        for (i in c.indices) for (j in i + 1 until c.size) {
            val dp = (pos(c[j]) - pos(c[i])).toDouble()
            if (abs(dp) < 1e-3 || c[j].value == c[i].value) continue
            val b = (c[j].value - c[i].value) / dp
            val a = c[i].value - b * pos(c[i])
            val inl = c.filter { abs(a + b * pos(it) - it.value) < 0.35 }
            if (inl.size > bestInliers.size) { bestInliers = inl; bestA = a; bestB = b }
        }
        if (bestInliers.size < 3) return null
        // least squares on inliers
        val xs = bestInliers.map { pos(it).toDouble() }
        val ys = bestInliers.map { it.value.toDouble() }
        val mx = xs.average(); val my = ys.average()
        var sxy = 0.0; var sxx = 0.0
        for (k in xs.indices) { sxy += (xs[k] - mx) * (ys[k] - my); sxx += (xs[k] - mx) * (xs[k] - mx) }
        if (sxx > 1e-9) { bestB = sxy / sxx; bestA = my - bestB * mx }
        return LineFit(bestA, bestB, bestInliers)
    }

    fun seqScore(values: List<Int>): Float {
        if (values.size < 3) return 0f
        var ok = 0
        for (i in 0 until values.size - 1) if (values[i + 1] == values[i] + 1) ok++
        return ok.toFloat() / (values.size - 1)
    }

    private fun isAnswerLine(ts: List<Token>): Boolean {
        if (ts.size < 2) return false
        val frac = ts.count { it.isAnswerLike }.toFloat() / ts.size
        return frac >= 0.8f && seqScore(ts.map { it.value }) < 0.5f
    }

    /** 1-D greedy clustering: sorted values join the current group while within [tol] of its mean. */
    fun <T> cluster(items: List<T>, tol: Float, key: (T) -> Float): List<List<T>> {
        val sorted = items.sortedBy(key)
        val groups = ArrayList<MutableList<T>>()
        var sum = 0.0
        for (item in sorted) {
            val k = key(item).toDouble()
            val g = groups.lastOrNull()
            if (g != null && k - sum / g.size <= tol) {
                g.add(item); sum += k
            } else {
                groups.add(mutableListOf(item)); sum = k
            }
        }
        return groups
    }
}
