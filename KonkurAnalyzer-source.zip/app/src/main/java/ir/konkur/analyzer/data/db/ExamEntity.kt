package ir.konkur.analyzer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exams")
data class ExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dateMillis: Long,
    val questionCount: Int,
    /** "name|from|to" entries joined with ";" */
    val sections: String,
    /** comma separated, one value per question */
    val keyAnswers: String,
    val studentAnswers: String,
    val optionsLeftToRight: Boolean,
    val blocksRightToLeft: Boolean,
    val correct: Int,
    val wrong: Int,
    val blank: Int,
    val percent: Double,
    val rawPercent: Double,
    val createdAt: Long,
)
