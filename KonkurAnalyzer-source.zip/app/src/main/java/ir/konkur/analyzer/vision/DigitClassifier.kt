package ir.konkur.analyzer.vision

import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.exp

/**
 * Tiny on-device MLP (784 → hidden → 10, ReLU, softmax) that classifies Persian digits ۰-۹.
 * Trained offline on synthetically rendered digits from 20+ Persian/Arabic fonts with rotation,
 * shear, blur, noise and stroke-width augmentation (see tools/train_digits.py).
 * Input: 28×28 float mask (ink = 1) where the glyph's bounding box is scaled so its longest side
 * is 20 px and centred, MNIST-style.
 */
class DigitClassifier private constructor(
    private val inSize: Int,
    private val hidden: Int,
    private val outSize: Int,
    private val w1: FloatArray,
    private val b1: FloatArray,
    private val w2: FloatArray,
    private val b2: FloatArray,
) {
    data class Prediction(val digit: Int, val confidence: Float)

    fun predict(input: FloatArray): Prediction {
        require(input.size == inSize)
        val h = FloatArray(hidden)
        for (j in 0 until hidden) h[j] = b1[j]
        for (i in 0 until inSize) {
            val x = input[i]
            if (x == 0f) continue
            val row = i * hidden
            for (j in 0 until hidden) h[j] += x * w1[row + j]
        }
        for (j in 0 until hidden) if (h[j] < 0f) h[j] = 0f
        val z = FloatArray(outSize) { b2[it] }
        for (j in 0 until hidden) {
            val v = h[j]
            if (v == 0f) continue
            val row = j * outSize
            for (k in 0 until outSize) z[k] += v * w2[row + k]
        }
        val max = z.max()
        var sum = 0.0
        val p = DoubleArray(outSize) { exp((z[it] - max).toDouble()).also { e -> sum += e } }
        var best = 0
        for (k in 1 until outSize) if (p[k] > p[best]) best = k
        return Prediction(best, (p[best] / sum).toFloat())
    }

    companion object {
        const val INPUT_SIDE = 28
        private const val MAGIC = 0x4B4F4E4B

        fun load(stream: InputStream): DigitClassifier {
            val bytes = stream.use { it.readBytes() }
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            require(bb.int == MAGIC) { "bad digit model" }
            val i = bb.int; val h = bb.int; val o = bb.int
            fun read(n: Int) = FloatArray(n).also { bb.asFloatBuffer().get(it); bb.position(bb.position() + n * 4) }
            val w1 = read(i * h); val b1 = read(h); val w2 = read(h * o); val b2 = read(o)
            return DigitClassifier(i, h, o, w1, b1, w2, b2)
        }
    }
}
