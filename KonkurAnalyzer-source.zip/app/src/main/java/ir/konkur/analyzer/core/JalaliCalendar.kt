package ir.konkur.analyzer.core

import java.util.Calendar
import java.util.TimeZone

data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    fun format(): String =
        PersianDigits.toPersian("%04d/%02d/%02d".format(year, month, day))

    fun formatLong(): String = "${day.fa()} ${JalaliCalendar.MONTHS[month - 1]} ${year.fa()}"
}

/** Gregorian <-> Jalali (Solar Hijri) conversion, based on the well known jalaali algorithm. */
object JalaliCalendar {
    val MONTHS = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun fromGregorian(gy: Int, gm: Int, gd: Int): JalaliDate {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + if (days < 186) days % 31 else (days - 186) % 30
        return JalaliDate(jy, jm, jd)
    }

    /** Returns (year, month[1-12], day). */
    fun toGregorian(jYear: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jYear + 1595
        var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
            if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days -= 1
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days += 1
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]
            gm++
        }
        return Triple(gy, gm, gd)
    }

    fun monthLength(year: Int, month: Int): Int = when {
        month <= 6 -> 31
        month <= 11 -> 30
        else -> if (isLeap(year)) 30 else 29
    }

    fun isLeap(year: Int): Boolean {
        // A Jalali year is leap when Esfand 30 maps to a valid date distinct from Farvardin 1.
        val (gy, gm, gd) = toGregorian(year, 12, 30)
        val back = fromGregorian(gy, gm, gd)
        return back.month == 12 && back.day == 30
    }

    fun fromMillis(millis: Long): JalaliDate {
        val c = Calendar.getInstance(TimeZone.getDefault())
        c.timeInMillis = millis
        return fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun toMillis(date: JalaliDate): Long {
        val (gy, gm, gd) = toGregorian(date.year, date.month, date.day)
        val c = Calendar.getInstance(TimeZone.getDefault())
        c.clear()
        c.set(gy, gm - 1, gd, 12, 0, 0)
        return c.timeInMillis
    }

    fun today(): JalaliDate = fromMillis(System.currentTimeMillis())
}
