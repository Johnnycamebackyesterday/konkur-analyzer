package ir.konkur.analyzer.ui.screens.setup

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.konkur.analyzer.core.JalaliCalendar
import ir.konkur.analyzer.core.PersianDigits
import ir.konkur.analyzer.domain.model.Section
import ir.konkur.analyzer.domain.scoring.ScoringEngine
import ir.konkur.analyzer.ui.components.BackButton
import ir.konkur.analyzer.ui.components.PrimaryButton
import ir.konkur.analyzer.ui.components.ScreenTitle
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(flow: ExamFlowViewModel, onBack: () -> Unit, onNext: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("تنظیم آزمون", "چند مشخصات کوتاه، بعد عکس‌ها را وارد می‌کنیم")
        OutlinedTextField(flow.name, { flow.setName(it) }, label = { Text("نام آزمون") }, placeholder = { Text("مثلاً آزمون جامع مهر") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            value = flow.date.format(), onValueChange = { v ->
                val p = PersianDigits.toLatin(v).split("/")
                if (p.size == 3) { val y = p[0].toIntOrNull(); val m = p[1].toIntOrNull(); val d = p[2].toIntOrNull(); if (y != null && m in 1..12 && d != null && d in 1..31) flow.setDate(ir.konkur.analyzer.core.JalaliDate(y, m, d)) }
            }, label = { Text("تاریخ شمسی") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Text("تعداد سؤال: ${PersianDigits.toPersian(flow.questionCount)}")
        Slider(value = flow.questionCount.toFloat(), onValueChange = { flow.setQuestionCount(it.toInt()) }, valueRange = 1f..400f, steps = 399)
        Text("چیدمان پاسخ‌برگ", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(flow.optionsLeftToRight, { flow.setLayout(it, flow.blocksRightToLeft) })
            Text("گزینه‌ها از راست به چپ نیستند (۱ سمت چپ)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(flow.blocksRightToLeft, { flow.setLayout(flow.optionsLeftToRight, it) })
            Text("بلوک‌ها از راست به چپ خوانده شوند")
        }
        Text("بخش‌های درسی (اختیاری)", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
        if (flow.sections.isEmpty()) Text("اگر بخش اضافه نکنید، گزارش کلی ساخته می‌شود.", color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
        flow.sections.forEachIndexed { i, s -> SectionEditor(s, { v -> flow.setSections(flow.sections.toMutableList().also { it[i] = v }) }, { flow.setSections(flow.sections.toMutableList().also { it.removeAt(i) }) }) }
        OutlinedButtonAdd { flow.setSections(flow.sections + Section("", 1, flow.questionCount)) }
        if (error != null) Text(error!!, color = androidx.compose.material3.MaterialTheme.colorScheme.error)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { BackButton(onBack); PrimaryButton("ادامه: عکس کلید", { error = ScoringEngine.validateSections(flow.sections, flow.questionCount); if (error == null) onNext() }, modifier = Modifier.weight(1f)) }
    }
}

@Composable private fun OutlinedButtonAdd(onClick: () -> Unit) { androidx.compose.material3.OutlinedButton(onClick, Modifier.fillMaxWidth()) { Text("+ افزودن بخش") } }

@Composable private fun SectionEditor(s: Section, onChange: (Section) -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedTextField(s.name, { onChange(s.copy(name = it)) }, label = { Text("نام درس") }, modifier = Modifier.weight(1.4f), singleLine = true)
        OutlinedTextField(s.from.toString(), { it.toIntOrNull()?.let { v -> onChange(s.copy(from = v)) } }, label = { Text("از") }, modifier = Modifier.weight(.7f), singleLine = true)
        OutlinedTextField(s.to.toString(), { it.toIntOrNull()?.let { v -> onChange(s.copy(to = v)) } }, label = { Text("تا") }, modifier = Modifier.weight(.7f), singleLine = true)
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "حذف بخش") }
    }
}
