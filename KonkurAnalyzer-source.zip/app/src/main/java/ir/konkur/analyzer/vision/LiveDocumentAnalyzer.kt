package ir.konkur.analyzer.vision

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import kotlin.math.abs
import kotlin.math.max

/** Result of analysing one preview frame; corners are normalised to 0..1 of the upright frame. */
data class LiveDetection(
    val corners: List<Pair<Float, Float>>?,
    val frameAspect: Float,
    val stability: Float,
) {
    val isStable: Boolean get() = corners != null && stability >= 1f
}

/**
 * CameraX analyzer for the guidance overlay: detects the sheet edges on the luminance plane and
 * tracks how still the sheet is, so the UI can auto-capture once it has been stable for a while.
 */
class LiveDocumentAnalyzer(
    private val stableFramesNeeded: Int = 12,
    private val onResult: (LiveDetection) -> Unit,
) : ImageAnalysis.Analyzer {

    private var last: List<Pair<Float, Float>>? = null
    private var stableCount = 0
    private var bytes = ByteArray(0)

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val w = image.width; val h = image.height
            val rowStride = plane.rowStride
            val buffer = plane.buffer
            if (bytes.size != w * h) bytes = ByteArray(w * h)
            if (rowStride == w) {
                buffer.rewind(); buffer.get(bytes, 0, w * h)
            } else {
                for (r in 0 until h) {
                    buffer.position(r * rowStride)
                    buffer.get(bytes, r * w, w)
                }
            }
            val mat = Mat(h, w, CvType.CV_8UC1)
            mat.put(0, 0, bytes)
            val upright = when (image.imageInfo.rotationDegrees) {
                90 -> Mat().also { Core.rotate(mat, it, Core.ROTATE_90_CLOCKWISE); mat.release() }
                180 -> Mat().also { Core.rotate(mat, it, Core.ROTATE_180); mat.release() }
                270 -> Mat().also { Core.rotate(mat, it, Core.ROTATE_90_COUNTERCLOCKWISE); mat.release() }
                else -> mat
            }
            val fw = upright.cols().toFloat(); val fh = upright.rows().toFloat()
            val quad = DocumentDetector.detect(upright, minAreaFraction = 0.15)
            upright.release()
            val corners = quad?.map { (it.x / fw).toFloat() to (it.y / fh).toFloat() }
            val prev = last
            if (corners != null && prev != null && DocumentDetector.normalizedArea(corners) > 0.2f) {
                var maxDelta = 0f
                for (i in corners.indices) {
                    maxDelta = max(maxDelta, max(abs(corners[i].first - prev[i].first), abs(corners[i].second - prev[i].second)))
                }
                stableCount = if (maxDelta < 0.015f) stableCount + 1 else 0
            } else {
                stableCount = 0
            }
            last = corners
            onResult(LiveDetection(corners, fw / fh, (stableCount.toFloat() / stableFramesNeeded).coerceAtMost(1f)))
        } catch (t: Throwable) {
            onResult(LiveDetection(null, 0.75f, 0f))
        } finally {
            image.close()
        }
    }

    fun reset() { stableCount = 0; last = null }
}
