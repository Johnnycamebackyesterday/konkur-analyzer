package ir.konkur.analyzer.domain.repository

import ir.konkur.analyzer.domain.model.Exam
import kotlinx.coroutines.flow.Flow

interface ExamRepository {
    fun observeAll(): Flow<List<Exam>>
    suspend fun get(id: Long): Exam?
    suspend fun save(exam: Exam): Long
    suspend fun delete(id: Long)
}
