package ir.konkur.analyzer.ui.screens.report

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import ir.konkur.analyzer.core.JalaliCalendar
import ir.konkur.analyzer.core.fa
import ir.konkur.analyzer.core.faPercent
import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.model.Report
import ir.konkur.analyzer.ui.components.BackButton
import ir.konkur.analyzer.ui.components.ErrorCard
import ir.konkur.analyzer.ui.components.ScoreSummary
import ir.konkur.analyzer.ui.components.ScreenTitle
import ir.konkur.analyzer.ui.flow.ExamFlowViewModel
import ir.konkur.analyzer.di.AppContainer

@Composable
fun ReportScreen(flow: ExamFlowViewModel, container: AppContainer, onHome: () -> Unit, onHistory: () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { if (flow.report == null) flow.calculate() }
    val r = flow.report
    if (r == null) { Column(Modifier.fillMaxSize().padding(20.dp)) { ErrorCard("گزارش هنوز آماده نیست") }; return }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("کارنامه آزمون", flow.name.ifBlank { "آزمون بدون نام" })
        Text(JalaliCalendar.fromMillis(JalaliCalendar.toMillis(flow.date)).formatLong(), color = Color.Gray)
        ScoreSummary(r.correct, r.wrong, r.blank, r.percent, r.rawPercent)
        Text("نمره منفی کنکور: هر سه پاسخ غلط، یک پاسخ صحیح را خنثی می‌کند.", color = Color.Gray, modifier = Modifier.fillMaxWidth())
        if (r.sections.isNotEmpty()) {
            Text("عملکرد دروس", style = MaterialTheme.typography.titleLarge)
            r.sections.forEach { s ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.section.name, style = MaterialTheme.typography.titleMedium); Text(s.percent.faPercent(), color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.height(8.dp))
                        Canvas(Modifier.fillMaxWidth().height(13.dp)) {
                            val w = size.width; val zero = w * .25f
                            drawRoundRect(Color(0xFFE0E0E0), topLeft = Offset(0f, 2f), size = androidx.compose.ui.geometry.Size(w, 9f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                            val end = (zero + (s.percent / 100.0 * w * .75)).toFloat().coerceIn(0f, w)
                            drawRoundRect(if (s.percent >= 0) Color(0xFF3F51B5) else Color(0xFFC62828), topLeft = Offset(minOf(zero, end), 2f), size = androidx.compose.ui.geometry.Size(abs(end-zero), 9f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
                        }
                        Text("صحیح ${s.correct.fa()}، غلط ${s.wrong.fa()}، نزده ${s.blank.fa()} از ${s.total.fa()}", color = Color.Gray)
                    }
                }
            }
        }
        OutcomeBlock("غلط‌ها (${r.wrongQuestions.size.fa()})", r.wrongQuestions, true)
        OutcomeBlock("نزده‌ها (${r.blankQuestions.size.fa()})", r.blankQuestions, false)
        if (flow.busy) Text("در حال ذخیره…")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onHome, modifier = Modifier.weight(1f)) { Text("خانه") }
            OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("تاریخچه") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { flow.save { } }, enabled = !flow.busy, modifier = Modifier.weight(1f)) { Text("ذخیره آزمون") }
            Button(onClick = {
                flow.save {
                    val exam = Exam(0, ir.konkur.analyzer.domain.model.ExamConfig(flow.name, ir.konkur.analyzer.core.JalaliCalendar.toMillis(flow.date), flow.questionCount, flow.sections), flow.keyCells.map { it.value }, flow.answerCells.map { it.value }, r)
                    val file = container.pdfExporter.export(exam)
                    context.startActivity(container.pdfExporter.shareIntent(file))
                }
            }, enabled = !flow.busy, modifier = Modifier.weight(1f)) { Text("خروجی PDF و اشتراک") }
        }
    }
}

@Composable private fun OutcomeBlock(title: String, list: List<ir.konkur.analyzer.domain.model.QuestionOutcome>, detailed: Boolean) {
    Text(title, style = MaterialTheme.typography.titleLarge)
    if (list.isEmpty()) Text("موردی ندارد، عالی!", color = Color.Gray)
    else Card(Modifier.fillMaxWidth()) { Text(list.joinToString("   ") { o -> "س${o.question.fa()}: ${if (detailed) "شما ${ans(o.student)}، کلید ${o.key.fa()}" else "کلید ${o.key.fa()}"}" }, Modifier.padding(12.dp)) }
}
private fun ans(a: Int) = when (a) { Answer.MULTI -> "چند"; Answer.BLANK -> "خالی"; else -> a.fa() }
private fun abs(x: Float) = kotlin.math.abs(x)
