package ir.konkur.analyzer.data.repository

import ir.konkur.analyzer.data.db.ExamDao
import ir.konkur.analyzer.domain.model.Exam
import ir.konkur.analyzer.domain.repository.ExamRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

class ExamRepositoryImpl(private val dao: ExamDao) : ExamRepository {
    override fun observeAll(): Flow<List<Exam>> =
        dao.observeAll().map { list -> list.map(ExamMapper::toDomain) }.flowOn(Dispatchers.Default)

    override suspend fun get(id: Long): Exam? = dao.get(id)?.let(ExamMapper::toDomain)
    override suspend fun save(exam: Exam): Long = dao.upsert(ExamMapper.toEntity(exam))
    override suspend fun delete(id: Long) = dao.delete(id)
}
