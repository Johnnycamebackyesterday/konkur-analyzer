package ir.konkur.analyzer.core

import java.util.Locale
import kotlin.math.abs

/** Conversion helpers between Latin, Persian (۰-۹) and Arabic-Indic (٠-٩) digits. */
object PersianDigits {
    private const val PERSIAN = "۰۱۲۳۴۵۶۷۸۹"

    fun toPersian(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            sb.append(
                when (c) {
                    in '0'..'9' -> PERSIAN[c - '0']
                    '.' -> '٫'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    fun toPersian(n: Int): String = toPersian(n.toString())
    fun toPersian(n: Long): String = toPersian(n.toString())

    /** Formats a number with [decimals] fraction digits, in Persian digits. */
    fun format(value: Double, decimals: Int = 1): String {
        val v = if (abs(value) < 0.05 && decimals <= 1) 0.0 else value
        return toPersian(String.format(Locale.US, "%.${decimals}f", v))
    }

    /** Normalises any Persian / Arabic-Indic digits in [input] to ASCII digits. */
    fun toLatin(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            sb.append(
                when (c) {
                    in '۰'..'۹' -> '0' + (c - '۰')
                    in '٠'..'٩' -> '0' + (c - '٠')
                    '٫' -> '.'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    /** Parses an int typed in any digit system; returns null when invalid. */
    fun parseInt(input: String): Int? = toLatin(input.trim()).toIntOrNull()
}

fun Int.fa(): String = PersianDigits.toPersian(this)
fun Double.faPercent(decimals: Int = 1): String = PersianDigits.format(this, decimals) + "٪"
