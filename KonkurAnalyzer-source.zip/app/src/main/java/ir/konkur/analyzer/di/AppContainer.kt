package ir.konkur.analyzer.di

import android.content.Context
import ir.konkur.analyzer.data.db.AppDatabase
import ir.konkur.analyzer.data.repository.ExamRepositoryImpl
import ir.konkur.analyzer.data.settings.SettingsRepository
import ir.konkur.analyzer.domain.repository.ExamRepository
import ir.konkur.analyzer.domain.usecase.DeleteExamUseCase
import ir.konkur.analyzer.domain.usecase.GetExamUseCase
import ir.konkur.analyzer.domain.usecase.GradeExamUseCase
import ir.konkur.analyzer.domain.usecase.ObserveHistoryUseCase
import ir.konkur.analyzer.domain.usecase.SaveExamUseCase
import ir.konkur.analyzer.domain.usecase.ScanAnswerKeyUseCase
import ir.konkur.analyzer.domain.usecase.ScanAnswerSheetUseCase
import ir.konkur.analyzer.export.PdfExporter
import ir.konkur.analyzer.vision.AnswerKeyScanner
import ir.konkur.analyzer.vision.AnswerSheetScanner
import ir.konkur.analyzer.vision.DigitClassifier

/** Manual dependency injection: one place that builds the object graph. */
class AppContainer(private val context: Context, val openCvReady: Boolean) {
    private val database by lazy { AppDatabase.build(context) }
    val examRepository: ExamRepository by lazy { ExamRepositoryImpl(database.examDao()) }
    val settings by lazy { SettingsRepository(context) }

    private val digitClassifier by lazy { DigitClassifier.load(context.assets.open("models/digit_mlp.bin")) }
    private val keyScanner by lazy { AnswerKeyScanner(digitClassifier) }
    private val sheetScanner by lazy { AnswerSheetScanner() }

    val gradeExam by lazy { GradeExamUseCase() }
    val saveExam by lazy { SaveExamUseCase(examRepository, gradeExam) }
    val getExam by lazy { GetExamUseCase(examRepository) }
    val deleteExam by lazy { DeleteExamUseCase(examRepository) }
    val observeHistory by lazy { ObserveHistoryUseCase(examRepository) }
    val scanAnswerKey by lazy { ScanAnswerKeyUseCase { keyScanner } }
    val scanAnswerSheet by lazy { ScanAnswerSheetUseCase { sheetScanner } }
    val pdfExporter by lazy { PdfExporter(context) }
}
