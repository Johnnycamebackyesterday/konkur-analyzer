package ir.konkur.analyzer.vision

import ir.konkur.analyzer.domain.model.Answer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BubbleClassifierTest {
    @Test fun `one strong mark`() { val r = BubbleClassifier.classify(floatArrayOf(.08f,.82f,.1f,.07f)); assertEquals(2,r.value); assertTrue(r.confidence > .9f) }
    @Test fun `all light is blank`() { assertEquals(Answer.BLANK, BubbleClassifier.classify(floatArrayOf(.1f,.12f,.11f,.09f)).value) }
    @Test fun `two strong marks are multi`() { assertEquals(Answer.MULTI, BubbleClassifier.classify(floatArrayOf(.8f,.78f,.1f,.08f)).value) }
    @Test fun `weak secondary mark remains inspectable`() { val r=BubbleClassifier.classify(floatArrayOf(.8f,.5f,.1f,.08f)); assertEquals(1,r.value); assertTrue(r.confidence < .6f) }
}
