package ir.konkur.analyzer.domain.scoring

import ir.konkur.analyzer.domain.model.Answer
import ir.konkur.analyzer.domain.model.Section
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ScoringEngineTest {
    @Test fun `all correct is 100`() {
        val r = ScoringEngine.grade(listOf(1,2,3,4), listOf(1,2,3,4), emptyList())
        assertEquals(4, r.correct); assertEquals(0, r.wrong); assertEquals(100.0, r.percent, .001)
    }
    @Test fun `three wrong cancel one correct`() {
        val r = ScoringEngine.grade(listOf(1,1,1,1), listOf(1,2,2,2), emptyList())
        assertEquals(1, r.correct); assertEquals(3, r.wrong); assertEquals(0.0, r.percent, .001)
    }
    @Test fun `blank is not wrong`() {
        val r = ScoringEngine.grade(listOf(1,2), listOf(0,2), emptyList())
        assertEquals(1, r.correct); assertEquals(0, r.wrong); assertEquals(1, r.blank); assertEquals(50.0, r.percent, .001)
    }
    @Test fun `multi mark is wrong`() {
        val r = ScoringEngine.grade(listOf(1), listOf(Answer.MULTI), emptyList())
        assertEquals(1, r.wrong); assertEquals(0, r.blank)
    }
    @Test fun `cancelled key excluded`() {
        val r = ScoringEngine.grade(listOf(1,0,2), listOf(1,1,0), emptyList())
        assertEquals(2, r.total); assertEquals(1, r.correct); assertEquals(0, r.wrong); assertEquals(1, r.blank); assertEquals(50.0, r.percent, .001)
    }
    @Test fun `section validation detects overlap`() {
        assertNull(ScoringEngine.validateSections(listOf(Section("زیست",1,20), Section("شیمی",21,40)), 40))
        assertEquals("بازه «زیست» و «شیمی» هم‌پوشانی دارند", ScoringEngine.validateSections(listOf(Section("زیست",1,20), Section("شیمی",20,40)), 40))
    }
}
