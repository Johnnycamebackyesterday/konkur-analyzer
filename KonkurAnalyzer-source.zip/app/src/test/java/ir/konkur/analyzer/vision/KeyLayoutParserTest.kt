package ir.konkur.analyzer.vision

import org.junit.Assert.assertEquals
import org.junit.Test

class KeyLayoutParserTest {
    private fun t(v:Int,x:Float,y:Float, answer:Boolean=false) = Token(v,1,if(answer) .99f else .98f,x,y,10f,24f)
    @Test fun `rows of pairs infer sequence despite missing tenth`() {
        val ts = (1..20).map { t(it, 100f, it*30f) } + (1..20).map { t((it%4)+1, 80f, it*30f, true) }
        val p = KeyLayoutParser.parse(ts,24f,20)
        assertEquals(20,p.answers.size); assertEquals(KeyLayout.ROWS_OF_PAIRS,p.layout)
    }
    @Test fun `fit line tolerates one bad digit`() {
        val ts=(1..20).map { t(if(it==10) 99 else it, it*20f, 0f) }
        val f=KeyLayoutParser.fitLine(ts,{it.cx},20)
        assertEquals(19,f!!.inliers.size)
    }
}
