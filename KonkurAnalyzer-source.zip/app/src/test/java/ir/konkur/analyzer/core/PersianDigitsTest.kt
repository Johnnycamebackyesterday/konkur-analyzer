package ir.konkur.analyzer.core

import org.junit.Assert.assertEquals
import org.junit.Test

class PersianDigitsTest {
    @Test fun `formats Persian digits`() { assertEquals("۱۲۳٫۵", PersianDigits.format(123.5,1)); assertEquals("۱۴۰۵/۰۷/۱۷", PersianDigits.toPersian("1405/07/17")) }
    @Test fun `round trips a Gregorian date`() { val j=JalaliCalendar.fromGregorian(2026,10,9); assertEquals(JalaliDate(1405,7,17),j); assertEquals(Triple(2026,10,9),JalaliCalendar.toGregorian(j.year,j.month,j.day)) }
}
